import { useState, useEffect, useCallback, Fragment } from 'react'
import { apiGet, apiPost, apiPut, apiDelete, apiPatch } from '../store'
import CatalogModal from '../components/CatalogModal'
import { StateSelect } from '../../../components/LocationSelect'

const styles = {
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' },
  input: { padding: '8px 12px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--line)', fontSize: '13px', outline: 'none', minWidth: '160px', background: 'var(--card-bg)', color: 'var(--ink)' },
  btn: { padding: '8px 16px', borderRadius: 'var(--radius-sm)', border: 'none', cursor: 'pointer', fontSize: '13px', fontWeight: 500 },
  card: { background: 'var(--card-bg)', boxShadow: 'var(--shadow)', borderRadius: 'var(--radius)', border: '1px solid var(--line)', overflow: 'hidden' },
  table: { width: '100%', borderCollapse: 'collapse', fontSize: '13px' },
  th: { padding: '10px 12px', textAlign: 'left', borderBottom: '2px solid var(--line)', fontWeight: 600, color: 'var(--ink-soft)', fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.5px', background: 'var(--bg)' },
  td: { padding: '10px 12px', borderBottom: '1px solid var(--bg)', color: 'var(--ink)', verticalAlign: 'top' },
  pill: (bg, fg) => ({ display: 'inline-block', padding: '2px 8px', borderRadius: '12px', fontSize: '11px', fontWeight: 600, background: bg, color: fg }),
  link: { color: 'var(--sage)', textDecoration: 'none', cursor: 'pointer', fontWeight: 500 },
  overlay: { position: 'fixed', inset: 0, background: 'rgba(15,23,42,.45)', zIndex: 50, display: 'flex', alignItems: 'flex-start', justifyContent: 'center', padding: '40px 16px', overflowY: 'auto' },
  modal: { background: 'var(--card-bg)', borderRadius: 'var(--radius)', boxShadow: 'var(--shadow)', maxWidth: 640, width: '100%', padding: '20px', border: '1px solid var(--line)' },
  field: { marginBottom: '12px' },
  label: { display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--ink-soft)', marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.5px' },
}

const fmtDate = (d) => (d ? new Date(d).toLocaleDateString('en-IN') : '—')
const fmtTime = (t) => (t ? String(t).slice(0, 5) : '—')
const fmtDateTime = (d) => {
  if (!d) return '—'
  const dt = new Date(d)
  if (isNaN(dt.getTime())) return '—'
  return dt.toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })
}

export default function Events() {
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)
  const [err, setErr] = useState('')

  const [showForm, setShowForm] = useState(false)
  const [edit, setEdit] = useState(null)
  const [form, setForm] = useState({ title: '', event_date: '', start_time: '', end_time: '', location: '', state: '', description: '' })
  const [saving, setSaving] = useState(false)

  // Per-event detail: marked beneficiaries
  const [openId, setOpenId] = useState(null)
  const [detail, setDetail] = useState({})

  // ── API users / catalogs ─────────────────────────────────────────────
  const [showOps, setShowOps] = useState(false)
  const [ops, setOps] = useState([])
  const [opsLoading, setOpsLoading] = useState(false)
  const [opsError, setOpsError] = useState('')
  const [opForm, setOpForm] = useState({ name: '', phone: '', email: '' })
  const [opSaving, setOpSaving] = useState(false)
  const [newOp, setNewOp] = useState(null)
  const [showKits, setShowKits] = useState(false)
  const [showOrganizers, setShowOrganizers] = useState(false)

  const loadOperators = useCallback(async () => {
    setOpsLoading(true)
    setOpsError('')
    try {
      const res = await apiGet('/beneficiaries/operators')
      setOps(res?.operators || [])
    } catch (e) {
      setOpsError(e.message || 'Failed to load operators')
    } finally {
      setOpsLoading(false)
    }
  }, [])

  useEffect(() => {
    if (showOps) loadOperators()
  }, [showOps, loadOperators])

  const openOpsModal = () => {
    setNewOp(null)
    setOpForm({ name: '', phone: '', email: '' })
    setOpsError('')
    setShowOps(true)
  }

  const createOperator = async () => {
    if (!opForm.name.trim()) {
      setOpsError('Operator name is required')
      return
    }
    setOpSaving(true)
    setOpsError('')
    try {
      const res = await apiPost('/beneficiaries/operators', {
        name: opForm.name.trim(),
        phone: opForm.phone.trim() || null,
        email: opForm.email.trim() || null,
      })
      setNewOp(res)
      setOps((prev) => [res.operator, ...prev])
      setOpForm({ name: '', phone: '', email: '' })
      await loadOperators()
    } catch (e) {
      setOpsError(e.message || 'Failed to create operator')
    } finally {
      setOpSaving(false)
    }
  }

  const toggleOperator = async (op) => {
    try {
      await apiPatch(`/beneficiaries/operators/${op.id}`, { is_active: !op.is_active })
      setOps((prev) => prev.map((o) => (o.id === op.id ? { ...o, is_active: !o.is_active } : o)))
    } catch (e) {
      setOpsError(e.message || 'Failed to update operator')
    }
  }

  const load = useCallback(async () => {
    setLoading(true)
    setErr('')
    try {
      const res = await apiGet('/operator/events')
      setEvents(Array.isArray(res) ? res : res?.events || [])
    } catch (e) {
      setErr(e.message || 'Failed to load events')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  const loadDetail = async (id) => {
    setOpenId(id === openId ? null : id)
    if (id === openId) return
    try {
      const beneficiaries = await apiGet(`/operator/events/${id}/beneficiaries`)
      setDetail((prev) => ({ ...prev, [id]: { beneficiaries: Array.isArray(beneficiaries) ? beneficiaries : [] } }))
    } catch (e) {
      setErr(e.message || 'Failed to load event details')
    }
  }

  const openNew = () => { setEdit(null); setForm({ title: '', event_date: '', start_time: '', end_time: '', location: '', state: '', description: '' }); setShowForm(true) }
  const openEdit = (ev) => {
    setEdit(ev)
    setForm({ title: ev.title || '', event_date: ev.event_date ? String(ev.event_date).slice(0, 10) : '', start_time: ev.start_time || '', end_time: ev.end_time || '', location: ev.location || '', state: ev.state || '', description: ev.description || '' })
    setShowForm(true)
  }

  const save = async () => {
    setSaving(true)
    setErr('')
    try {
if (edit) await apiPut(`/operator/events/${edit.id}`, form)
      else await apiPost('/operator/events', form)
      setShowForm(false)
      await load()
    } catch (e) {
      setErr(e.message || 'Failed to save event')
    } finally {
      setSaving(false)
    }
  }

  const remove = async (id) => {
    if (!confirm('Delete this event?')) return
    try {
      await apiDelete(`/operator/events/${id}`)
      setDetail((prev) => { const n = { ...prev }; delete n[id]; return n })
      setOpenId(null)
      await load()
    } catch (e) {
      setErr(e.message || 'Failed to delete event')
    }
  }

  return (
    <div>
      <div style={styles.header}>
        <div>
          <h2 style={{ fontSize: '20px', fontWeight: 700, color: 'var(--ink)', margin: 0 }}>Events</h2>
          <div style={{ fontSize: '12px', color: 'var(--ink-soft)', marginTop: '2px' }}>
            Events the app operators pick every day. Beneficiaries marked (kit given) roll up under the event.
          </div>
        </div>
<div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <button onClick={() => setShowKits(true)} style={{ ...styles.btn, background: 'var(--bg)', color: 'var(--ink)' }}>
            Kits
          </button>
          <button onClick={() => setShowOrganizers(true)} style={{ ...styles.btn, background: 'var(--bg)', color: 'var(--ink)' }}>
            Organizers
          </button>
          <button onClick={openOpsModal} style={{ ...styles.btn, background: 'var(--bg)', color: 'var(--ink)' }}>
            Operators
          </button>
          <button onClick={openNew} style={{ ...styles.btn, background: 'var(--sage)', color: '#fff' }}>+ New Event</button>
        </div>
      </div>

      {err && (
        <div style={{ padding: '10px 12px', borderRadius: 'var(--radius-sm)', background: '#fee2e2', color: '#991b1b', fontSize: '13px', marginBottom: '12px' }}>{err}</div>
      )}

      {showForm && (
        <div style={styles.overlay} onClick={() => setShowForm(false)}>
          <div style={styles.modal} onClick={(e) => e.stopPropagation()}>
            <h3 style={{ fontSize: '17px', fontWeight: 700, color: 'var(--ink)', margin: 0, marginBottom: '16px' }}>
              {edit ? 'Edit Event' : 'New Event'}
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
              <div style={styles.field}>
                <label style={styles.label}>Title *</label>
                <input style={{ ...styles.input, width: '100%' }} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              </div>
              <div style={styles.field}>
                <label style={styles.label}>Date *</label>
                <input type="date" style={{ ...styles.input, width: '100%' }} value={form.event_date} onChange={(e) => setForm({ ...form, event_date: e.target.value })} />
              </div>
              <div style={styles.field}>
                <label style={styles.label}>Start time</label>
                <input type="time" style={{ ...styles.input, width: '100%' }} value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} />
              </div>
              <div style={styles.field}>
                <label style={styles.label}>End time</label>
                <input type="time" style={{ ...styles.input, width: '100%' }} value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} />
              </div>
              <div style={styles.field}>
                <label style={styles.label}>Location</label>
                <input style={{ ...styles.input, width: '100%' }} value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
              </div>
              <div style={styles.field}>
                <label style={styles.label}>State</label>
                <StateSelect value={form.state} onChange={(v) => setForm((p) => ({ ...p, state: v }))} ariaLabel="State" />
              </div>
              <div style={{ ...styles.field, gridColumn: '1 / -1' }}>
                <label style={styles.label}>Description</label>
                <textarea rows={2} style={{ ...styles.input, width: '100%', fontFamily: 'inherit' }} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
              <button onClick={() => setShowForm(false)} style={{ ...styles.btn, background: 'var(--bg)', color: 'var(--ink)' }}>Cancel</button>
              <button onClick={save} disabled={saving || !form.title || !form.event_date} style={{ ...styles.btn, background: 'var(--sage)', color: '#fff', opacity: saving || !form.title || !form.event_date ? 0.6 : 1 }}>
                {saving ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}

      <div style={styles.card}>
        {loading ? (
          <div style={{ padding: '40px', textAlign: 'center', color: 'var(--ink-soft)' }}>Loading...</div>
        ) : events.length === 0 ? (
          <div style={{ padding: '40px', textAlign: 'center', color: 'var(--ink-soft)' }}>No events. Add one above.</div>
        ) : (
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Title</th>
                <th style={styles.th}>Date</th>
                <th style={styles.th}>Time</th>
                <th style={styles.th}>Location</th>
                <th style={styles.th}></th>
              </tr>
            </thead>
            <tbody>
              {events.map((ev) => {
                const open = openId === ev.id
                const d = detail[ev.id]
                return (
                  <Fragment key={ev.id}>
                    <tr style={{ cursor: 'pointer' }} onClick={() => loadDetail(ev.id)}>
                      <td style={styles.td}>{ev.title}</td>
                      <td style={styles.td}>{fmtDate(ev.event_date)}</td>
                      <td style={styles.td}>{fmtTime(ev.start_time)} – {fmtTime(ev.end_time)}</td>
                      <td style={styles.td} className="sa-muted">{ev.location || ev.state || '—'}</td>
                      <td style={styles.td}>
                        <button className="btn btn-sm" onClick={(e) => { e.stopPropagation(); openEdit(ev) }}>Edit</button>
                        <button className="btn btn-sm btn-danger" onClick={(e) => { e.stopPropagation(); remove(ev.id) }} style={{ marginLeft: 4 }}>Del</button>
                      </td>
                    </tr>
                    {open && (
                      <tr>
                        <td colSpan={5} style={{ ...styles.td, background: 'var(--bg)', padding: '18px' }}>
                          {/* Marked beneficiaries */}
                          <div style={{ background: 'var(--card-bg)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--line)', padding: '12px' }}>
                            <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--ink)', marginBottom: '8px' }}>
                              Beneficiaries marked (kit given) here · {(d?.beneficiaries || []).length}
                            </div>
                            {(d?.beneficiaries || []).length === 0 ? (
                              <div style={{ fontSize: '12px', color: 'var(--ink-soft)' }}>None yet. When the operator marks a bonus beneficiary at this event, it shows up here.</div>
                            ) : (
                              <table style={styles.table}>
                                <tbody>
                                  {(d?.beneficiaries || []).map((b) => (
                                    <tr key={b.audit_id}>
                                      <td style={{ ...styles.td, borderBottom: '1px solid var(--line)' }}>{b.full_name}</td>
                                      <td style={{ ...styles.td, borderBottom: '1px solid var(--line)', width: '30%' }}>{b.beneficiary_code}</td>
                                      <td style={{ ...styles.td, borderBottom: '1px solid var(--line)', width: '30%' }}>{fmtDateTime(b.performed_at)}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            )}
                          </div>
                        </td>
                      </tr>
                    )}
                  </Fragment>
                )
              })}
            </tbody>
</table>
        )}
      </div>

      {/* App Operators modal */}
      {showOps && (
        <div style={styles.overlay} onClick={() => setShowOps(false)}>
          <div style={styles.modal} onClick={(e) => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <div>
                <h3 style={{ fontSize: '17px', fontWeight: 700, color: 'var(--ink)', margin: 0 }}>App Operators</h3>
                <div style={{ fontSize: '12px', color: 'var(--ink-soft)', marginTop: '2px' }}>
                  Only these accounts can log into the Beneficiaries mobile app.
                </div>
              </div>
              <button onClick={() => setShowOps(false)} style={{ ...styles.btn, background: 'var(--bg)', color: 'var(--ink)' }}>Close</button>
            </div>

            {opsError && (
              <div style={{ padding: '10px 12px', borderRadius: 'var(--radius-sm)', background: '#fee2e2', color: '#991b1b', fontSize: '13px', marginBottom: '12px' }}>{opsError}</div>
            )}

            {newOp && (
              <div style={{ padding: '12px', borderRadius: 'var(--radius-sm)', background: '#dcfce7', color: '#166534', fontSize: '13px', marginBottom: '12px' }}>
                <strong>Operator created.</strong> Share these credentials with <strong>{newOp.operator?.name}</strong>:
                <div style={{ marginTop: '8px', display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
                  <span><span style={{ opacity: .7 }}>Login ID:</span> <code>{newOp.login_id}</code></span>
                  <span><span style={{ opacity: .7 }}>Password:</span> <code>{newOp.password}</code></span>
                </div>
              </div>
            )}

            {/* Add operator form */}
            <div style={{ border: '1px solid var(--line)', borderRadius: 'var(--radius-sm)', padding: '14px', marginBottom: '16px' }}>
              <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--ink)', marginBottom: '10px' }}>Add operator</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div style={styles.field}>
                  <label style={styles.label}>Name *</label>
                  <input style={{ ...styles.input, width: '100%' }} value={opForm.name} onChange={(e) => setOpForm({ ...opForm, name: e.target.value })} placeholder="e.g. Riya Sharma" />
                </div>
                <div style={styles.field}>
                  <label style={styles.label}>Mobile</label>
                  <input style={{ ...styles.input, width: '100%' }} value={opForm.phone} onChange={(e) => setOpForm({ ...opForm, phone: e.target.value })} placeholder="10-digit mobile" />
                </div>
                <div style={{ ...styles.field, gridColumn: '1 / -1' }}>
                  <label style={styles.label}>Email (optional)</label>
                  <input style={{ ...styles.input, width: '100%' }} value={opForm.email} onChange={(e) => setOpForm({ ...opForm, email: e.target.value })} placeholder="operator@beingsevak.org" />
                </div>
              </div>
              <button onClick={createOperator} disabled={opSaving} style={{ ...styles.btn, background: 'var(--sage)', color: '#fff', marginTop: '4px', opacity: opSaving ? .6 : 1 }}>
                {opSaving ? 'Adding...' : '+ Add Operator'}
              </button>
            </div>

            {/* Operator list */}
            <div>
              <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--ink)', marginBottom: '8px' }}>
                {opsLoading ? 'Loading...' : `${ops.length} operator${ops.length === 1 ? '' : 's'}`}
              </div>
              {!opsLoading && ops.length === 0 && (
                <div style={{ padding: '20px', textAlign: 'center', color: 'var(--ink-soft)', fontSize: '13px' }}>
                  No operators yet. Add one above to let them log into the app.
                </div>
              )}
              {!opsLoading && ops.length > 0 && (
                <table style={styles.table}>
                  <thead>
                    <tr>
                      <th style={styles.th}>Name</th>
                      <th style={styles.th}>Login ID</th>
                      <th style={styles.th}>Contact</th>
                      <th style={styles.th}>Status</th>
                      <th style={styles.th}>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {ops.map((op) => (
                      <tr key={op.id}>
                        <td style={styles.td}>{op.name}</td>
                        <td style={styles.td}><code style={{ fontSize: '12px', background: 'var(--bg)', padding: '2px 6px', borderRadius: 'var(--radius-sm)' }}>{op.login_id}</code></td>
                        <td style={styles.td}>{op.phone || op.email || '-'}</td>
                        <td style={styles.td}>{op.is_active ? <span style={styles.pill('#dcfce7', '#166534')}>Active</span> : <span style={styles.pill('var(--bg)', 'var(--ink-soft)')}>Inactive</span>}</td>
                        <td style={styles.td}>
                          <button onClick={() => toggleOperator(op)} style={{ ...styles.btn, background: 'var(--bg)', color: op.is_active ? '#991b1b' : 'var(--ink)' }}>
                            {op.is_active ? 'Deactivate' : 'Activate'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Kit catalog modal */}
      {showKits && (
        <CatalogModal
          kind="kits"
          title="Kits"
          subtitle="Kits the operators hand out. Shown as a dropdown on the app's Operator Details screen."
          onClose={() => setShowKits(false)}
        />
      )}

      {/* Organizer catalog modal */}
      {showOrganizers && (
        <CatalogModal
          kind="organizers"
          title="Organizers"
          subtitle="Who runs the program. Shown as a dropdown on the app's Operator Details screen."
          onClose={() => setShowOrganizers(false)}
        />
      )}
    </div>
  )
}
