import { useState, useEffect, useCallback, useRef } from 'react';
import { createPortal } from 'react-dom';
import { getMyDonors, getQueueCurrent, getMyStations, getDonorDetail, addDonorLog, markDonorSeen, uploadPaymentScreenshot, getDonorDonations, searchDonorsByMobile, updateDonorType, getMyDisposedLeads, getScheduled, getCallbacks, getPromises, getOverdue } from '../api/donors';
import { api, isImpersonating, getUser } from '../../../api/auth';
import { SkeletonMyLeads } from '../../../components/Skeleton';
import { toast } from '../../../components/Toast';
import { useRealtime } from '../../../hooks/useRealtime';
import { DatePicker } from '../components/ui';
import { TimePicker } from '../components/TimePicker';
import { DispositionDropdown } from '../components/DispositionDropdown';
import { useCall } from '../CallContext';
import { extractTransactionData } from '../utils/ocr';
import usePasteImage from '../../../utils/usePasteImage';
import { API_BASE } from '../../../lib/apiBase';
import { useIsMobile } from '../../../hooks/useIsMobile';
import { CONNECTED_QUICK, NOT_CONNECTED_QUICK, OTHERS_ID, isConnected, findDisp, STATUS_PILL_MAP, SCHEDULE_DATE_TYPES, SCHEDULE_TIME_TYPES } from '../dispositions';
import { istDateString, istDateTimeToIso } from '../utils/time';

function callFmt(seconds) {
  if (seconds == null) return '00:00'
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
}

const PROJECTS = [
  'Mission Annapurna', 'Mission Vidhya', 'Mission Aurat', 'Mission Bezubaan',
  'Mission Atmanirbhar', 'Mission Arogya', 'Sevak Seva Kendra', 'Mission Eco-Warriors',
];
const PAN_REGEX = /^[A-Z]{5}[0-9]{4}[A-Z]$/;

// A save button stuck on "Loading..." for the shared api() default 120s is
// unusable in the field. 20s is generous for a screenshot upload on a slow
// link and short enough that the panel recovers on its own.
const SAVE_TIMEOUT_MS = 20000;

const DISP_TO_STATUS = { office_visit_scheduled: 'scheduled', program_visit_scheduled: 'scheduled' };

const isCollectionLog = (log) =>
  log.action === 'donation' ||
  log.disposition_detail === 'done' ||
  (log.disposition_detail === 'lead_done' && log.accounts_status === 'verified');

// Includes the grouped picker IDs — without them a recycled lead sorts as
// fresh (tier 0/1) ahead of genuinely unused pending leads. Mirrors backend.
const RETRYABLE_NOT_CONNECTED = new Set([
  'ringing', 'unreachable', 'busy', 'out_of_coverage', 'voicemail', 'call_waiting', 'switched_off',
  'ringing_voicemail', 'busy_call_waiting', 'ooc_unreachable_network',
]);
// Statuses the QUEUE treats as not-workable-anymore. This is deliberately NOT
// applied to the My Leads list: the list shows every allotted donor, narrowed only
// by the "Hidden: N" toggle, so a FRO's allotment and their visible list always
// reconcile and nothing silently vanishes (it previously removed 6+ leads on top
// of the backend's own filtering).
//
// It is still used by applyDonorPatch, which is what advances the #1 -> #2
// cursor: a lead that was just dispositioned must leave the queue immediately or
// the next donor served is the one that was just worked.
const HIDDEN_STATUSES = new Set([
  'lead_done', 'donation_collected', 'done', 'visit_donate',
  'will_donate_online', 'promise_to_pay', 'payment_pending', 'already_donated',
  'scheduled', 'callback', 'follow_up', 'office_visit_scheduled', 'program_visit_scheduled',
  'wrong_number', 'invalid_number', 'invalid', 'rejected',
  'temporary_network_issue', 'incoming_out',
  'not_interested', 'not_interested_now', 'dnd', 'wrong_person', 'not_possible', 'language_barrier',
  'call_disconnected',
  'others',
]);
// My Leads = pending + retryable not-connected work. A lead with any other
// status has already been dispositioned this month and belongs in History /
// Callbacks / Follow-ups / Overdue — the backend returns the same set, and
// this filter is the client-side guarantee (realtime patches / list merges can
// never re-introduce a worked lead). The monthly rollover resets every worked
// status back to 'pending', so a lead disposed last month re-enters here.

// Why a donor is held back, as flagged by the backend (is_suppressed /
// suppress_reason). Used for the per-row badge so "why can't I work this lead?"
// is always answerable on screen.
const SUPPRESS_REASON_LABELS = {
  dnd: 'DND — do not contact',
  donated_this_month: 'Donated this month',
  disposed_today: 'Already dispositioned today',
  hard_terminal: 'Closed — do not rework',
  money_done: 'Donation completed',
  scheduled: 'Scheduled / callback',
  terminal_forever: 'Closed — do not rework',
  not_connected_forever: 'Closed — do not rework',
};
// DONOR_STATUS_GROUPS / DONOR_STATUS_GROUP_LABELS (the "All statuses" dropdown that
// grouped pending / retryable / scheduled / donated / rejected) were removed
// alongside the "Donated: hidden" toggle: both hid allotted work behind controls
// that were easy to leave enabled. The per-row SUPPRESS_REASON_LABELS badge still
// explains any individual lead, so nothing is opaque without them.

// Queue-only filter: drops donors the backend already considers worked/done so
// the auto-advance cursor never re-serves them. The My Leads LIST shows only
// 'pending' leads (see filterAndSortDonors), so the queue and the list agree.
function filterDonors(list) {
  return list.filter(d => !HIDDEN_STATUSES.has(d.status));
}

function dedupeDonors(list) {
  const seen = new Set();
  const out = [];
  for (const d of list || []) {
    const key = `${d.id ?? d.donor_id}|${d.ngo_id ?? ''}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(d);
  }
  return out;
}

function isPendingStatus(d) {
  // NULL/empty status = never-worked assignment; treated as pending.
  // Retryable not-connected leads (ringing/busy/…) stay workable: the backend
  // drops the ones dialled today and returns them the next day at the tail.
  return d.status === 'pending' || d.status == null || d.status === ''
    || RETRYABLE_NOT_CONNECTED.has(d.status);
}
// Sorts the fetched list, keeping ONLY 'pending' leads. My Leads is the FRO's
// queue of work still to do; anything already dispositioned this month lives in
// History / Callbacks / Follow-ups / Overdue and comes back here when the
// monthly rollover resets it to pending.
function filterAndSortDonors(list) {
  return dedupeDonors(list).filter(isPendingStatus).sort((a, b) => {
      // Suppressed (DND / donated this month) always sorts last so the
      // workable stack stays on top even with "Show suppressed" on.
      const aHidden = a.is_suppressed ? 1 : 0;
      const bHidden = b.is_suppressed ? 1 : 0;
      if (aHidden !== bHidden) return aHidden - bHidden;
      // Pure "never-called / pending" leads go on top: everything the FRO has
      // already put a claim on (ringing, busy, scheduled, …) sits below.
      const aPending = a.status === 'pending' || a.status == null || a.status === '';
      const bPending = b.status === 'pending' || b.status == null || b.status === '';
      if (aPending !== bPending) return aPending ? -1 : 1;
      // Oldest called first, most recently called after.
      const ca = a.last_contacted_at ? new Date(a.last_contacted_at).getTime() : null;
      const cb = b.last_contacted_at ? new Date(b.last_contacted_at).getTime() : null;
      if (ca === null && cb !== null) return 1;
      if (ca !== null && cb === null) return -1;
      if (ca !== null && cb !== null && ca !== cb) return ca - cb;
      const ta = a.assigned_at ? new Date(a.assigned_at).getTime() : 0;
      const tb = b.assigned_at ? new Date(b.assigned_at).getTime() : 0;
      return ta - tb;
    });
}

function normalizeDonorResponse(r) {
  if (Array.isArray(r)) return { donors: r, total: r.length };
  return { donors: r?.donors || [], total: r?.total ?? (r?.donors?.length || 0) };
}

function findNextDonorIndex(donors, currentId) {
  const idx = donors.findIndex(d => d.id === currentId);
  if (idx >= 0) {
    for (let i = idx + 1; i < donors.length; i++) {
      if (donors[i].id !== currentId) return i;
    }
  }
  // Strictly forward: never wrap last → first. If nothing after the current
  // donor, the queue is complete for now (the backend is authoritative).
  return -1;
}

function applyDonorPatch(list, donorId, ngoId, patch) {
  // Preserve the current queue order while applying the patch — only filter out
  // hidden/done donors, do NOT re-sort. Re-sorting here would move a just-fired
  // disposition (e.g. ringing -> retryable tail) to the end of the list, making
  // the next-lead cursor jump to a random "#N" instead of advancing #1 -> #2 -> #3.
  return filterDonors(list.map(d =>
    d.id === donorId && d.ngo_id === ngoId ? { ...d, ...patch } : d
  ));
}

function DonationDoneStamp({ donor }) {
  const monthLabel = new Date().toLocaleString('en-IN', { month: 'long', year: 'numeric' });
  const type = donor.donor_type;
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0, alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: '0 8px' }}>
      <div style={{ width: '100%', maxWidth: 380 }}>
        <div style={{
          transform: 'rotate(-4deg)',
          background: 'linear-gradient(135deg, #16a34a 0%, #15803d 100%)',
          color: '#fff',
          border: '3px dashed #bbf7d0',
          borderRadius: 10,
          padding: '24px 22px',
          boxShadow: '0 12px 32px rgba(22,163,74,.28)',
        }}>
          <div style={{ width: 68, height: 68, borderRadius: '50%', background: 'rgba(255,255,255,.18)', border: '2px solid rgba(255,255,255,.75)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px' }}>
            <span className="material-symbols-outlined" style={{ fontSize: 42, color: '#fff', fontWeight: 700 }}>check</span>
          </div>
          <div style={{ fontSize: type === 'one_time' ? 20 : 18, fontWeight: 900, letterSpacing: 1.2 }}>
            {type === 'quarterly'
              ? 'DONATION FOR THIS QUARTER DONE'
              : type === 'half_yearly'
              ? 'DONATION FOR THIS HALF-YEAR DONE'
              : type === 'yearly'
              ? 'DONATION FOR THIS YEAR DONE'
              : type === 'one_time'
              ? 'ONE TIME DONATION DONE'
              : 'DONATION FOR THIS MONTH DONE'}
          </div>
          <div style={{ marginTop: 12 }}>
            <span style={{ display: 'inline-block', border: '2px solid #fff', borderRadius: 999, padding: '3px 16px', fontSize: 10, fontWeight: 800, letterSpacing: .8 }}>
              {donor.has_verified_donation_current_month ? '✓  VERIFIED' : '�  PENDING VERIFICATION'}
            </span>
          </div>
        </div>
        <div style={{ marginTop: 22, fontSize: 11, color: 'var(--ink-soft)', lineHeight: 1.5 }}>
          {type === 'quarterly' ? (
            <>This donor already donated for this quarter. Press <strong>NEXT</strong> to continue to the next donor.</>
          ) : type === 'half_yearly' ? (
            <>This donor already donated for this half-year. Press <strong>NEXT</strong> to continue to the next donor.</>
          ) : type === 'yearly' ? (
            <>This donor already donated for this year. Press <strong>NEXT</strong> to continue to the next donor.</>
          ) : type === 'one_time' ? (
            <>This donor has already donated. Press <strong>NEXT</strong> to continue to the next donor.</>
          ) : (
            <>This donor already donated for {monthLabel}. Press <strong>NEXT</strong> to continue to the next donor.</>
          )}
        </div>
      </div>
    </div>
  );
}
function useTomorrowStr() {
  const t = new Date();
  t.setDate(t.getDate() + 1);
  return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`;
}

const initials = (name) => (name || '').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();

// How many leads the MY LEADS list renders at a time. The allotment can be
// thousands of rows; rendering them all at once makes the list janky on low-end
// phones and wastes paint on rows nobody scrolls to. The window grows by this
// many each time the FRO nears the bottom.
const LEADS_PAGE_SIZE = 10;

// Client-side search memo. Mirrors the server cache so a term the FRO already
// searched this session (a backspace, a re-typed prefix, switching back to a
// station) renders instantly instead of re-querying. Short-lived on purpose —
// a lead's disposition changes what a search should return.
const SEARCH_CACHE_TTL_MS = 30 * 1000;
const SEARCH_CACHE_MAX = 50;
// Must sit above a normal inter-keystroke gap (~150-300ms) so that typing a
// number keeps resetting the timer and produces ONE request when typing stops,
// rather than one per character.
const SEARCH_DEBOUNCE_MS = 600;
const SEARCH_MIN_CHARS = 2;
const SEARCH_MIN_DIGITS = 3;

export default function MyDonors({ embedded = false, portalEl = null }) {
  const isMobile = useIsMobile()
  const isCompact = useIsMobile(480)
  const [donors, setDonors] = useState([]);
  const [total, setTotal] = useState(0);
  const [dataTab, setDataTab] = useState('new');
  const [loading, setLoading] = useState(true);
  const [index, setIndex] = useState(0);
  const [detail, setDetail] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [leadAmount, setLeadAmount] = useState('');
  const [selected, setSelected] = useState(null);
  const [notes, setNotes] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [dateConfirmed, setDateConfirmed] = useState(false);
  const [callbackTime, setCallbackTime] = useState('');
  const [leadScreenshot, setLeadScreenshot] = useState(null);
  const [leadAddress, setLeadAddress] = useState('');
  const [leadPan, setLeadPan] = useState('');
  const [panError, setPanError] = useState('');
  const [leadDob, setLeadDob] = useState('');
  const [projectName, setProjectName] = useState('');
  const [leadRemark, setLeadRemark] = useState('');
  const [showRemark, setShowRemark] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [remarkError, setRemarkError] = useState(false);
  const [showAllRemarks, setShowAllRemarks] = useState(false);
  const [upiTransactionId, setUpiTransactionId] = useState('');
  const [transactionDatetime, setTransactionDatetime] = useState('');
  const [ocrFromName, setOcrFromName] = useState('');
  const [ocrLoading, setOcrLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null);
  const prevActionRef = useRef(null);
  const [showConfirmPrev, setShowConfirmPrev] = useState(false);
  const [showDonationModal, setShowDonationModal] = useState(false);
  const [donations, setDonations] = useState([]);
  const [donationFilter, setDonationFilter] = useState('all');
  const [donationLoading, setDonationLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [disposedResults, setDisposedResults] = useState([]);
  const [disposedSearchLoading, setDisposedSearchLoading] = useState(false);
  const [returnToDonor, setReturnToDonor] = useState(null);
  const [resumeTo, setResumeTo] = useState(null);
  const [showAllLogs, setShowAllLogs] = useState(false);
  const [externalDonor, setExternalDonor] = useState(null);
  const backendSearchTimerRef = useRef(null);
  const searchCacheRef = useRef(new Map());
  const searchInflightRef = useRef(new Map());
  // Mirrors the term the FRO last typed, so a late-arriving response can tell
  // whether it is still wanted.
  const latestSearchRef = useRef('');
  const debounceReloadRef = useRef(null);
  const initialMountRef = useRef(true);
  const pendingSelectRef = useRef(null);
  const manualTabSwitchRef = useRef(false);
  // True while the current tab was chosen by the empty-tab probe (not by an
  // explicit FRO click). While true, saveProgress omits data_tab so an automatic
  // Old<->New shunt never gets persisted as the FRO's permanent tab, which could
  // otherwise pin them to the wrong tab next session (the "incognito shows data /
  // Old tab empty" confusion). Cleared on a manual tab switch.
  const autoChoseTabRef = useRef(false);
  const autoFallbackAttemptedRef = useRef(false);
  // Suppresses realtime-triggered reloads right after the FRO saves a
  // disposition. Logging a lead often causes the backend to INSERT/UPDATE a
  // fro_assignments row (findOrCreateAssignment), whose realtime event would
  // otherwise refetch + re-sort the list and snap the position indicator to a
  // "random" number. We let the local list update be authoritative for a short
  // window so the cursor advances sequentially (#1 -> #2 -> #3).
  const suppressRealtimeUntilRef = useRef(0);
  const [stations, setStations] = useState([]);
  const VIEW_STATE_KEY = 'mydonors_view_state';
  const savedView = (() => { try { return JSON.parse(localStorage.getItem(VIEW_STATE_KEY)); } catch { return null; } })();
  const [selectedStation, setSelectedStation] = useState(savedView?.selectedStation || 'all');
  const [selectedNgo, setSelectedNgo] = useState(savedView?.selectedNgo || null);
  // MY LEADS list view: the currently opened lead (null = showing the list).
  const [activeDonor, setActiveDonor] = useState(null);
  // Whether the MY LEADS list includes donors the backend flagged as suppressed
  // (DND, donated this month, or already worked/closed). Default OFF so
  // the working stack stays clean, but every one of those donors is reachable in
  // one click and always counted — nothing is silently missing.
  const [listShowSuppressed, setListShowSuppressed] = useState(false);
  const [listView, setListView] = useState('leads'); // 'leads' | 'followups' | 'history'
  const [historyLeads, setHistoryLeads] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  // Bumped whenever a disposition is saved. History is otherwise only fetched
  // when the tab is entered, so a lead worked in this session would not show up
  // there — nor in its count badge — until the FRO left and came back.
  const [historyRefresh, setHistoryRefresh] = useState(0);
  const [followUps, setFollowUps] = useState([]);
  const [followUpsLoading, setFollowUpsLoading] = useState(false);
  // Preserves the list's vertical scroll position while the FRO opens a lead
  // and returns (or disposes it), so the list doesn't snap back to the top.
  const listScrollRef = useRef(null);
  const savedListScrollRef = useRef(0);
  // Incremental rendering window for the MY LEADS list. `visibleCount` is how
  // many leads are currently rendered; the list grows by LEADS_PAGE_SIZE as the
  // FRO scrolls toward the bottom. `hasMoreRef` mirrors "are there rows past the
  // window" — it is assigned during render (the list items are derived below the
  // hooks) so the scroll handler can decide whether to grow.
  const [visibleCount, setVisibleCount] = useState(LEADS_PAGE_SIZE);
  const hasMoreRef = useRef(false);

  // Any change to what the list *should* show collapses the window back to the
  // first page — the previous offset refers to a different ordering. Realtime
  // reloads deliberately do NOT reset it: a new lead should not yank an FRO who
  // has scrolled deep back to the top mid-task.
  useEffect(() => {
    setVisibleCount(LEADS_PAGE_SIZE);
  }, [listView, dataTab, selectedStation, selectedNgo, searchQuery, listShowSuppressed]);

  // Grow the render window as the FRO reaches the bottom of the list. Reading
  // `hasMoreRef` (rather than the item count) keeps this handler free of the
  // render-local list derivation, and the `+ LEADS_PAGE_SIZE` bump means a single
  // long flick can grow it several pages without one request per pixel.
  const handleListScroll = useCallback(() => {
    const el = listScrollRef.current;
    if (!el || !hasMoreRef.current) return;
    const remaining = el.scrollHeight - el.scrollTop - el.clientHeight;
    if (remaining <= 320) setVisibleCount(c => c + LEADS_PAGE_SIZE);
  }, []);
  const { isOnCall, activeCall, endCall, todayStats, startDonorView, endDonorView, adoptTimer, adoptOptimisticDisposition, noteDispositionSaved } = useCall();

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setResumeTo(null);
    setExternalDonor(null);

    const load = async (tab) => {
      try {
        // Capture localStorage snapshot BEFORE any state changes (avoids race condition)
        const sk = selectedStation !== 'all' ? selectedStation : 'all';
        const savedSnapshot = (() => { try { return JSON.parse(localStorage.getItem(`${tab}_${sk}_donor_progress`)); } catch { return null; } })();

        const r = await getMyDonors(null, null, stationOpts(tab, selectedStation));
        if (cancelled) return;
        let { donors: loaded, total: rTotal } = normalizeDonorResponse(r);
        let sortedDonors = filterAndSortDonors(loaded);
        // Stale-filter escape: if this tab is filtered (NGO/station) and comes
        // back EMPTY, but the SAME tab with no filter has data, the previously
        // saved filter (localStorage view state) is stale — its leads were
        // worked/disposed, and it is silently hiding the FRO's remaining leads
        // (the classic "only shows after opening incognito" symptom). Drop the
        // stale filter and surface the real queue instead of an empty list.
        const staleFilterActive = !!((selectedStation && selectedStation !== 'all') || selectedNgo);
        if (staleFilterActive && sortedDonors.length === 0) {
          const br = await getMyDonors(null, null, {
            newOnly: tab === 'new',
            oldOnly: tab === 'old',
            includeSuppressed: true,
          });
          if (cancelled) return;
          const broad = filterAndSortDonors(normalizeDonorResponse(br).donors);
          if (broad.length > 0) {
            setSelectedStation('all');
            setSelectedNgo(null);
            sortedDonors = broad;
            rTotal = broad.length;
          }
        }
        // Auto-fallback: if the current tab is genuinely empty, probe the other tab
        // (new<->old) ONCE and, if it has leads, switch — but only after telling
        // the user, via the autoFallbackAttemptedRef banner, rather than silently.
        // The previous version switched tabs with no indication at all, which is
        // how an FRO could sit on the New tab convinced their Old allotment was
        // empty. The combined-empty banner below already covers the both-empty
        // case, so we no longer need autoTabRef / autoFallbackToOldRef.
        if (sortedDonors.length === 0 && !manualTabSwitchRef.current && !autoFallbackAttemptedRef.current) {
          autoFallbackAttemptedRef.current = true;
          const otherTab = tab === 'new' ? 'old' : 'new';
          const alt = await getMyDonors(null, null, {
            ...stationOpts(otherTab, selectedStation),
            includeSuppressed: true,
          });
          if (cancelled) return;
          const altList = filterAndSortDonors(normalizeDonorResponse(alt).donors);
          if (altList.length > 0) {
            autoChoseTabRef.current = true;
            setDataTab(otherTab);
            setSelected(null);
            return;
          }
        }
        // Data found (in either tab) — clear the "we already looked" flag so a
        // later empty load can probe again.
        if (sortedDonors.length > 0) {
          autoFallbackAttemptedRef.current = false;
        }
        setDonors(sortedDonors);
        setTotal(rTotal);
        setMessage(null);
        let restored = false;

        if (pendingSelectRef.current) {
          const { donorId } = pendingSelectRef.current;
          pendingSelectRef.current = null;
          const found = sortedDonors.findIndex(d => d.id === donorId);
          if (found >= 0) {
            setIndex(found);
            restored = true;
          } else {
            setMessage({ type: 'error', text: 'This donor exists but isn\u2019t in your active list (already marked done). Open via Donor Detail or contact admin.' });
          }
        }

        // Restore from localStorage snapshot (captured before state changes)
        if (savedSnapshot) {
          const { id, idx } = savedSnapshot;
          if (id) {
            const found = sortedDonors.findIndex(d => d.id === id);
            if (found >= 0) { setIndex(found); restored = true; }
          }
          if (!restored && typeof idx === 'number' && idx < sortedDonors.length) {
            setIndex(idx); restored = true;
          }
        }

        // Fallback to backend progress (for cross-device restore)
        if (!restored) {
          try {
            const progress = await api('/fro/progress', { _prefix: 'ucs' });
            const progressStation = progress?.station || 'all';
            if (progressStation === (selectedStation !== 'all' ? selectedStation : 'all')) {
              const savedId = tab === 'new' ? progress?.new_donor_id : progress?.old_donor_id;
              if (savedId) {
                const found = sortedDonors.findIndex(d => d.id === savedId);
                if (found >= 0) { setIndex(found); restored = true; }
              }
              if (!restored) {
                const savedIndex = tab === 'new' ? progress?.new_donor_index : progress?.old_donor_index;
                if (savedIndex != null && savedIndex < sortedDonors.length) {
                  setIndex(savedIndex); restored = true;
                }
                }
              }
            } catch (e) { console.error('Error:', e.message); }
        }

        if (!restored) setIndex(0);
      } catch (err) {
        if (!cancelled) setMessage({ type: 'error', text: err.message });
      } finally {
        if (!cancelled) {
          setLoading(false);
          // allow next auto-fallback after one manual switch cycle completes
          setTimeout(() => { manualTabSwitchRef.current = false; }, 100);
        }
      }
    };

    // On first mount, restore the saved tab and position from progress
    (async () => {
      if (initialMountRef.current) {
        initialMountRef.current = false;
        try {
          const progress = await api('/fro/progress', { _prefix: 'ucs' });
          if (progress?.data_tab && progress.data_tab !== dataTab) {
            setDataTab(progress.data_tab);
            return;
          }
        } catch (e) { console.error('Error:', e.message); }
      }
      load(dataTab);
    })();

    return () => { cancelled = true; };
  }, [dataTab, selectedStation, selectedNgo]);

  useEffect(() => {
    if (donors.length > 0 && index >= donors.length) {
      setIndex(0);
    }
  }, [donors.length]);

  useEffect(() => {
    if (message && message.type !== 'error') {
      const t = setTimeout(() => setMessage(null), 4000);
      return () => clearTimeout(t);
    }
  }, [message]);

  useEffect(() => {
    // Only track a "donor view" when a lead is actually open (list view has none).
    const viewing = activeDonor || externalDonor;
    if (!viewing) { endDonorView(false); return; }
    const target = activeDonor || externalDonor;
    if (target?.id) {
      endDonorView(false)
      startDonorView(target.id)
    }
  }, [index, donors, activeDonor, externalDonor, endDonorView, startDonorView]);

  // When returning to the list from an opened lead, restore the previously
  // saved scroll position so the FRO doesn't get thrown back to the top.
  useEffect(() => {
    if (!activeDonor) {
      const el = listScrollRef.current;
      if (el && savedListScrollRef.current) {
        el.scrollTop = savedListScrollRef.current;
      }
    }
  }, [activeDonor]);

  useEffect(() => {
    getMyStations().then(s => {
      const arr = Array.isArray(s) ? s : [];
      setStations(arr);
      // Acting FRO: default to claimed station (e.g. DH-1) not saved FD-1/all
      if (isImpersonating()) {
        try {
          const u = getUser('ucs');
          const act = Array.isArray(u?.act_stations) ? u.act_stations : [];
          if (act.length > 0) {
            const allowed = new Set(act.map(p => String(p.station ?? '').trim()));
            const cur = String(selectedStation ?? '').trim();
            if (!allowed.has(cur)) {
              setSelectedStation(String(act[0].station ?? '').trim() || (arr[0]?.station || 'all'));
            }
          }
        } catch {}
      }
      if (!savedView?.selectedNgo) {
        const ngoMap = {};
        arr.forEach(st => { if (st.ngo_id && !ngoMap[st.ngo_id]) ngoMap[st.ngo_id] = st.ngo_name || st.ngo_id; });
        const ngoList = Object.entries(ngoMap).map(([id, name]) => ({ ngo_id: id, ngo_name: name }));
        if (ngoList.length === 1) setSelectedNgo(ngoList[0].ngo_id);
      }
    }).catch((err) => { console.error('API error:', err.message); });
  }, []);

  const stationOpts = (tab, station) => {
    const opts = { newOnly: tab === 'new', oldOnly: tab === 'old' };
    // Ask the backend for the FULL allotted list. It returns every assigned donor
    // and flags the suppressed ones (is_suppressed / suppress_reason) rather than
    // deleting them, so the list can show everything behind the "Show
    // suppressed" toggle and reconcile with the allotment count.
    opts.includeSuppressed = true;
    if (station && station !== 'all') opts.station = station;
    if (selectedNgo) opts.ngoId = selectedNgo;
    return opts;
  };

  const reloadDonors = useCallback(() => {
    const current = donorsRef.current[indexRef.current];
    const currentId = current?.id;
    const currentNgo = current?.ngo_id;
    getMyDonors(null, null, stationOpts(dataTab, selectedStation)).then(r => {
      const { donors: loaded, total: rTotal } = normalizeDonorResponse(r);
      const fresh = filterAndSortDonors(loaded);
      // Preserve the current on-screen order so a background reload after a
      // save never re-sorts the queue and snaps the "#N of M" cursor to a
      // random value. Walk the existing list first (refreshing in place), then
      // append any genuinely new donors in the server's order.
      const existing = donorsRef.current;
      const freshMap = new Map(fresh.map(d => [`${d.id ?? d.donor_id}|${d.ngo_id ?? ''}`, d]));
      const keyOf = (d) => `${d.id ?? d.donor_id}|${d.ngo_id ?? ''}`;
      const merged = [];
      const mergedKeys = new Set();
      for (const d of existing) {
        const k = keyOf(d);
        if (mergedKeys.has(k)) continue;
        mergedKeys.add(k);
        if (freshMap.has(k)) merged.push(freshMap.get(k));
      }
      for (const d of dedupeDonors(fresh)) {
        const k = keyOf(d);
        if (mergedKeys.has(k)) continue;
        mergedKeys.add(k);
        merged.push(d);
      }
      if (currentId != null) {
        const newIdx = merged.findIndex(x => x.id === currentId && x.ngo_id === currentNgo);
        if (newIdx >= 0 && indexRef.current !== newIdx) setIndex(newIdx);
      }
      setDonors(merged);
      setTotal(rTotal);
    }).catch((err) => { console.error('API error:', err.message); });
  }, [dataTab, selectedStation, selectedNgo]);

  const debouncedReload = useCallback(() => {
    if (debounceReloadRef.current) clearTimeout(debounceReloadRef.current);
    debounceReloadRef.current = setTimeout(() => reloadDonors(), 2000);
  }, [reloadDonors]);

  // History: fetch all disposed leads for this FRO (leads already worked)
  useEffect(() => {
    if (listView !== 'history' || activeDonor) return;
    let cancelled = false;
    setHistoryLoading(true);
    const opts = {};
    if (selectedStation !== 'all') opts.station = selectedStation;
    if (selectedNgo) opts.ngoId = selectedNgo;
    getMyDisposedLeads(opts).then(r => {
      if (cancelled) return;
      const arr = Array.isArray(r) ? r : r?.data || [];
      setHistoryLeads(arr);
    }).catch(() => { if (!cancelled) setHistoryLeads([]); })
      .finally(() => { if (!cancelled) setHistoryLoading(false); });
    return () => { cancelled = true; };
  }, [listView, activeDonor, selectedStation, selectedNgo, historyRefresh]);

  // Follow-ups: scheduled contacts + callback assignments + money promises,
  // merged/deduplicated the same way the standalone Follow Ups page did.
  useEffect(() => {
    if (listView !== 'followups' || activeDonor) return;
    let cancelled = false;
    setFollowUpsLoading(true);
    Promise.all([getScheduled(), getCallbacks(), getPromises()])
      .then(([scheduled, callbacks, promises]) => {
        if (cancelled) return;
        const todayStr = istDateString();
        const items = [];
        const seen = new Set();
        const k = (d) => `${d.id}`;
        (scheduled || []).forEach(d => {
          if (d.scheduled_at && istDateString(d.scheduled_at) !== todayStr && !seen.has(k(d))) {
            seen.add(k(d));
            items.push({ id: d.id, ngo_id: d.ngo_id, ngo_name: d.ngo_name, owner_name: d.owner_name, donor_name: d.donor_name, donor_mobile: d.donor_mobile, station: d.station || null, scheduled_at: d.scheduled_at, type: 'scheduled' });
          }
        });
        (callbacks || []).forEach(d => {
          if (!seen.has(k(d))) {
            seen.add(k(d));
            items.push({ id: d.id, ngo_id: d.ngo_id, ngo_name: d.ngo_name, owner_name: d.owner_name, donor_name: d.donor_name, donor_mobile: d.donor_mobile, station: d.station || null, scheduled_at: d.scheduled_at || null, type: 'callback' });
          }
        });
        (scheduled || []).forEach(d => {
          if (d.scheduled_at && istDateString(d.scheduled_at) === todayStr && !seen.has(k(d))) {
            seen.add(k(d));
            items.push({ id: d.id, ngo_id: d.ngo_id, ngo_name: d.ngo_name, owner_name: d.owner_name, donor_name: d.donor_name, donor_mobile: d.donor_mobile, station: d.station || null, scheduled_at: d.scheduled_at, type: 'callback' });
          }
        });
        (promises || []).forEach(d => {
          if (!seen.has(k(d))) {
            seen.add(k(d));
            items.push({ id: d.id, ngo_id: d.ngo_id, ngo_name: d.ngo_name, owner_name: d.owner_name, donor_name: d.donor_name, donor_mobile: d.donor_mobile, station: d.station || null, scheduled_at: d.due_date || d.scheduled_at || null, due_date: d.due_date || null, type: 'promise' });
          }
        });
        setFollowUps(items);
      })
      .catch((err) => { if (!cancelled) { console.error('Follow-ups error:', err.message); setFollowUps([]); } })
      .finally(() => { if (!cancelled) setFollowUpsLoading(false); });
    return () => { cancelled = true; };
  }, [listView, activeDonor]);

  // Overdue tab: server-side list of every lead whose follow-up date (across all
  // past days/months) has passed and is still open — most overdue first.
  const [overdueLeads, setOverdueLeads] = useState([]);
  useEffect(() => {
    if (listView !== 'overdue' || activeDonor) return;
    let cancelled = false;
    setFollowUpsLoading(true);
    getOverdue()
      .then((list) => { if (!cancelled) setOverdueLeads(list || []); })
      .catch((err) => { if (!cancelled) { console.error('Overdue error:', err.message); setOverdueLeads([]); } })
      .finally(() => { if (!cancelled) setFollowUpsLoading(false); });
    return () => { cancelled = true; };
  }, [listView, activeDonor]);

  const donorsRef = useRef(donors);
  const indexRef = useRef(index);
  donorsRef.current = donors;
  indexRef.current = index;
  const savingRef = useRef(false);

  const jumpToDonor = async (donorId, ngoId) => {
    const found = donors.findIndex(d => d.id === donorId && (!ngoId || d.ngo_id === ngoId));
    if (found >= 0) {
      setIndex(found);
      return true;
    }
    return false;
  };


  const isInsertInCurrentView = (row) => {
    if (!row) return false;
    if (row.status === 'reassigned') return false;
    if (row.batch_type && row.batch_type !== (dataTab === 'old' ? 'old_data' : 'new_data')) return false;
    if (selectedStation !== 'all' && row.station !== selectedStation) return false;
    if (selectedNgo && row.ngo_id && row.ngo_id !== selectedNgo) return false;
    return true;
  };

  useRealtime('fro_assignments', {
    event: 'INSERT',
    onInsert: (row) => {
      if (Date.now() < suppressRealtimeUntilRef.current) return;
      if (isInsertInCurrentView(row)) debouncedReload();
    },
  });

  const saveProgress = useCallback((tab, donorId, donorIndex) => {
    if (!donorId) return;
    // Don't persist an auto-fallback-chosen tab as the FRO's permanent tab. The
    // empty-tab shunt is transient; only an explicit tab click should move the
    // saved data_tab. Otherwise a shunted FRO stays pinned to the wrong tab on
    // their next session.
    const body = { station: selectedStation !== 'all' ? selectedStation : null };
    // Don't persist a fallback-chosen tab as the FRO's permanent tab. The
    // empty-tab probe is transient; only an explicit tab click should move the
    // saved data_tab. Otherwise a shunted FRO stays pinned to the wrong tab on
    // their next session.
    if (!autoChoseTabRef.current) body.data_tab = tab;
    if (tab === 'new') {
      body.new_donor_id = donorId;
      body.new_donor_index = donorIndex;
    } else {
      body.old_donor_id = donorId;
      body.old_donor_index = donorIndex;
    }
    api('/fro/progress', { method: 'PUT', body: JSON.stringify(body), _prefix: 'ucs' }).catch((err) => { console.error('API error:', err.message); });
  }, [selectedStation]);

  const stationKey = selectedStation !== 'all' ? selectedStation : 'all';

  const switchTab = (tab) => {
    manualTabSwitchRef.current = true;
    autoChoseTabRef.current = false;
    autoFallbackAttemptedRef.current = false;
    if (donor) {
      saveProgress(dataTab, donor.id, index);
      localStorage.setItem(`${dataTab}_${stationKey}_donor_progress`, JSON.stringify({ id: donor.id, idx: index }));
    }
    setSelected(null);
    setDataTab(tab);
  };

  const donor = activeDonor || externalDonor || donors[index];

  useEffect(() => {
    if (!donor) return;
    localStorage.setItem(`mydonors_current_donor_${stationKey}`, JSON.stringify({ id: donor.id, ngo_id: donor.ngo_id, idx: index }));
  }, [donor?.id, donor?.ngo_id, index, stationKey]);

  const progressRef = useRef({ donor, index, dataTab });
  progressRef.current = { donor, index, dataTab };
  const formStateRef = useRef({});
  useEffect(() => {
    const handleBeforeUnload = () => {
      const p = progressRef.current;
      if (p.donor) {
        try {
          localStorage.setItem(`${p.dataTab}_${stationKey}_donor_progress`, JSON.stringify({ id: p.donor.id, idx: p.index }));
          const body = { data_tab: p.dataTab, station: selectedStation !== 'all' ? selectedStation : null };
          if (p.dataTab === 'new') { body.new_donor_id = p.donor.id; body.new_donor_index = p.index; }
          else { body.old_donor_id = p.donor.id; body.old_donor_index = p.index; }
          navigator.sendBeacon && navigator.sendBeacon(
            API_BASE + '/fro/progress',
            JSON.stringify(body)
          );
        } catch (e) { /* silent */ }
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      saveViewState();
      const p = progressRef.current;
      if (p.donor) {
        saveFormState();
        localStorage.setItem(`${p.dataTab}_${stationKey}_donor_progress`, JSON.stringify({ id: p.donor.id, idx: p.index }));
        saveProgress(p.dataTab, p.donor.id, p.index);
      }
    };
  }, [stationKey, selectedStation]);
  const logs = detail?.logs || [];
  const totalCollected = detail?.total_collected || 0;
  const nextSchedule = detail?.next_schedule;
  const effCategory = selectedCategory || (selected ? (isConnected(selected) ? 'connected' : 'not_connected') : null);
  const remarks = logs.filter(l => (l.remark && String(l.remark).trim()) || (l.notes && String(l.notes).trim()));
  const dispLabel = (l) => l.action === 'disposition'
    ? (findDisp(l.disposition_detail)?.label || String(l.disposition_detail || '').replace(/_/g, ' ') || 'Disposition')
    : String(l.action || '').replace(/_/g, ' ');

  const resetFormState = () => {
    setSelected(null); setSelectedCategory(null); setNotes(''); setScheduledDate(''); setScheduledTime(''); setCallbackTime('');
    setLeadScreenshot(null); setScreenshotPreview(null); setLeadAddress(''); setLeadPan(''); setPanError('');
    setLeadDob(''); setProjectName(''); setLeadAmount(''); setLeadRemark(''); setShowRemark(false);
    setRemarkError(false); setShowAllRemarks(false);
    setUpiTransactionId(''); setTransactionDatetime(''); setOcrFromName(''); setOcrLoading(false);
    setShowDonationPrompt(false); setDonationEntering(false); setDonationAmt(''); setDonationSaving(false);
    setDonationDt(new Date().toISOString().slice(0, 10));
    setMessage(null);
  };

  const formStateKey = (donorId) => `mydonors_form_state_${donorId}`;

  const saveFormState = () => {
    const f = formStateRef.current;
    if (!f.donor) return;
    const state = {
      selected: f.selected, selectedCat: f.selectedCategory, notes: f.notes, scheduledDate: f.scheduledDate, scheduledTime: f.scheduledTime, dateConfirmed: f.dateConfirmed, callbackTime: f.callbackTime,
      leadScreenshot: f.leadScreenshot, screenshotPreview: f.screenshotPreview, leadAddress: f.leadAddress, leadPan: f.leadPan, panError: f.panError,
      leadDob: f.leadDob, projectName: f.projectName, leadAmount: f.leadAmount, leadRemark: f.leadRemark, showRemark: f.showRemark,
      upiTransactionId: f.upiTransactionId, transactionDatetime: f.transactionDatetime, ocrFromName: f.ocrFromName,
      showDonationPrompt: f.showDonationPrompt, donationEntering: f.donationEntering, donationAmt: f.donationAmt, donationDt: f.donationDt,
    };
    localStorage.setItem(formStateKey(f.donor.id), JSON.stringify(state));
  };

  const restoreFormState = () => {
    if (!donor) return;
    const saved = localStorage.getItem(formStateKey(donor.id));
    if (!saved) return;
    try {
      const s = JSON.parse(saved);
      setSelected(s.selected);
      setSelectedCategory(s.selectedCat || (s.selected ? (isConnected(s.selected) ? 'connected' : 'not_connected') : null));
      setNotes(s.notes || '');
      setScheduledDate(s.scheduledDate || '');
      setScheduledTime(s.scheduledTime || '');
      setDateConfirmed(s.dateConfirmed || false);
      setCallbackTime(s.callbackTime || '');
      setLeadScreenshot(s.leadScreenshot || null);
      setScreenshotPreview(s.screenshotPreview || null);
      setLeadAddress(s.leadAddress || '');
      setLeadPan(s.leadPan || '');
      setPanError(s.panError || '');
      setLeadDob(s.leadDob || '');
      setProjectName(s.projectName || '');
      setLeadAmount(s.leadAmount || '');
      setLeadRemark(s.leadRemark || '');
      setShowRemark(s.showRemark || false);
      setUpiTransactionId(s.upiTransactionId || '');
      setTransactionDatetime(s.transactionDatetime || '');
      setOcrFromName(s.ocrFromName || '');
      setShowDonationPrompt(s.showDonationPrompt || false);
      setDonationEntering(s.donationEntering || false);
      setDonationAmt(s.donationAmt || '');
      setDonationDt(s.donationDt || new Date().toISOString().slice(0, 10));
    } catch (e) { /* ignore */ }
  };

  const clearFormState = () => {
    if (!donor) return;
    localStorage.removeItem(formStateKey(donor.id));
    resetFormState();
  };

  const saveViewState = () => {
    localStorage.setItem(VIEW_STATE_KEY, JSON.stringify({
      selectedStation, selectedNgo, dataTab,
      donorId: donor?.id || null,
      donorIdx: donor ? index : null,
    }));
  };

  useEffect(() => {
    if (donor) restoreFormState();
  }, [donor?.id]);

  const [donorTypeSaving, setDonorTypeSaving] = useState(false);
  const [showDonationPrompt, setShowDonationPrompt] = useState(false);
  const [donationAmt, setDonationAmt] = useState('');
  const [donationDt, setDonationDt] = useState(() => new Date().toISOString().slice(0, 10));
  const [donationSaving, setDonationSaving] = useState(false);
  const [donationEntering, setDonationEntering] = useState(false);
  const handleDonorTypeChange = async (e) => {
    const newType = e.target.value;
    if (!donor || !newType || newType === (donor.donor_type || '')) return;
    const donorId = donor.id;
    const prevType = donor.donor_type;
    setDonors(prev => prev.map(d => d.id === donorId ? { ...d, donor_type: newType } : d));
    setDonorTypeSaving(true);
    try {
      await updateDonorType(donorId, newType);
      setShowDonationPrompt(true);
      setDonationEntering(false);
      setDonationAmt('');
      setDonationDt(new Date().toISOString().slice(0, 10));
      setMessage(null);
    } catch (err) {
      console.error('updateDonorType error:', err.message);
      setDonors(prev => prev.map(d => d.id === donorId ? { ...d, donor_type: prevType } : d));
      setMessage({ type: 'error', text: 'Failed to update donor type' });
    } finally {
      setDonorTypeSaving(false);
    }
  };

  const handleDonationYes = () => {
    setDonationEntering(true);
    setDonationAmt('');
    setDonationDt(new Date().toISOString().slice(0, 10));
  };

  const handleDonationNo = () => {
    setShowDonationPrompt(false);
    setDonationEntering(false);
    setDonationAmt('');
  };

  const handleDonationSave = async () => {
    if (!donationAmt || isNaN(donationAmt) || Number(donationAmt) <= 0) {
      setMessage({ type: 'error', text: 'Enter a valid donation amount' });
      return;
    }
    if (!donationDt) {
      setMessage({ type: 'error', text: 'Select donation date' });
      return;
    }
    if (savingRef.current) return;
    savingRef.current = true;
    setDonationSaving(true);
    setMessage(null);
    // Restart the window at submit time; the saved.timer below replaces it with
    // the server's answer if the request lands.
    adoptOptimisticDisposition();
    try {
      // Adopt the server's timer answer straight away. The next heartbeat would
      // carry the same deadline, but waiting for it leaves the 4-minute clock
      // stale for up to 30s right after the FRO's first action of the day.
      const saved = await addDonorLog(donor.id, {
        action: 'donation',
        amount_collected: Number(donationAmt),
        transaction_datetime: new Date(donationDt).toISOString(),
        notes: `Donation recorded (${donor.donor_type})`,
        ngo_id: donor.ngo_id,
      }, { timeout: SAVE_TIMEOUT_MS });
      if (saved?.timer) adoptTimer(saved.timer);
      noteDispositionSaved();
      // A disposition changes what a search should return for that donor, and the
      // server cache is already dropped by invalidateFroCaches() — so the browser
      // memo has to go with it. Without this, re-searching the same term inside
      // the 30s TTL would still show the lead the FRO just closed.
      searchCacheRef.current.clear();
      // The lead the FRO just worked belongs in History now; refetch it so the
      // tab and its badge are current the moment they look.
      setHistoryRefresh(k => k + 1);
      setShowDonationPrompt(false);
      setDonationEntering(false);
      setDonationAmt('');
      setMessage({ type: 'success', text: 'Donation recorded' });
      const newDonors = applyDonorPatch(donorsRef.current, donor.id, donor.ngo_id, { status: 'donation_collected', is_new: false });
      setDonors(newDonors);
      // Backend-authoritative next donor.
      const advance = () => goToBackendNext(donor);
      if (resumeTo) {
        const ridx = newDonors.findIndex(d => d.id === resumeTo.id && d.ngo_id === resumeTo.ngo_id);
        setResumeTo(null);
        if (ridx >= 0) {
          setIndex(ridx);
          saveProgress(dataTab, newDonors[ridx].id, ridx);
        } else {
          advance();
        }
      } else {
        advance();
      }
      clearFormState();
    } catch (err) {
      const offline = /abort|timeout|failed to fetch|network|load failed/i.test(err?.message || '');
      setMessage({ type: 'error', text: offline ? 'Could not reach the server — nothing was saved. Check your connection and try again.' : err.message });
    } finally {
      setDonationSaving(false);
      savingRef.current = false;
    }
  };

  const cancelledRef = useRef(false);
  const loadDetail = useCallback(() => {
    // Only load detail for an OPENED lead (list view has no active donor).
    if (!donor || (!activeDonor && !externalDonor)) { setDetail(null); return; }
    cancelledRef.current = false;
    const id = donor.id;
    const ngoId = donor.ngo_id;
    setDetailLoading(true);
    if (donor.is_new) {
      markDonorSeen(id, ngoId).then(() => {
        if (!cancelledRef.current) {
          setDonors(prev => prev.map(d =>
            d.id === id && d.ngo_id === ngoId ? { ...d, is_new: false } : d
          ));
        }
      }).catch(err => console.error('markDonorSeen error:', err));
    }
    getDonorDetail(id, ngoId).then(d => {
      if (cancelledRef.current) return;
      setDetail(d); setShowAllLogs(false); setShowAllRemarks(false);
      // Prefill the Notes / Remark fields from the donor's most recent saved
      // log (latest first). The FRO's saved notes must show when a lead returns.
      const logs = d?.logs || [];
      let lastNotes = '';
      let lastRemark = '';
      for (const l of logs) {
        if (!lastNotes && l.notes) lastNotes = l.notes;
        if (!lastRemark && l.remark) lastRemark = l.remark;
        if (lastNotes && lastRemark) break;
      }
      // Only prefill from stored history, never clobber a fresh local note the
      // FRO already typed this session.
      setNotes(prev => (prev && prev.trim()) ? prev : lastNotes);
      setLeadRemark(prev => (prev && prev.trim()) ? prev : lastRemark);
    }).catch(err => console.error('getDonorDetail error:', err)).finally(() => { if (!cancelledRef.current) setDetailLoading(false); });
  }, [donor?.id, donor?.ngo_id, activeDonor, externalDonor]);

  useEffect(() => { return () => { cancelledRef.current = true; }; }, [loadDetail]);

  useEffect(() => { loadDetail(); }, [loadDetail]);

  const handleDropdownChange = (detailId, category) => {
    setSelected(detailId);
    setSelectedCategory(category);
    setRemarkError(false);
    setMessage(null);
    if (detailId === OTHERS_ID) {
      setShowRemark(true);
    }
    if (SCHEDULE_DATE_TYPES.has(detailId)) {
      const d = new Date();
      d.setDate(d.getDate() + 1);
      setScheduledDate(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`);
      setScheduledTime('');
      setDateConfirmed(false);
    }
    if (SCHEDULE_TIME_TYPES.has(detailId)) {
      const now = new Date();
      setCallbackTime(now.toTimeString().slice(0, 5));
    }
    if (detailId === 'lead_done') {
      setProjectName(donor?.donor_project || '');
      setLeadAmount('');
      setPanError('');
    } else if (detailId === 'done') {
      setLeadAmount('');
    } else {
      setLeadScreenshot(null);
      setScreenshotPreview(null);
      setLeadAddress('');
      setLeadPan('');
      setPanError('');
      setLeadDob('');
      setProjectName('');
      setLeadAmount('');
      setUpiTransactionId('');
      setTransactionDatetime('');
      setOcrFromName('');
      setOcrLoading(false);
    }
  };

  const [screenshotPreview, setScreenshotPreview] = useState(null);
  formStateRef.current = {
    donor, selected, selectedCategory, notes, scheduledDate, scheduledTime, dateConfirmed, callbackTime,
    leadScreenshot, screenshotPreview, leadAddress, leadPan, panError,
    leadDob, projectName, leadAmount, leadRemark, showRemark,
    upiTransactionId, transactionDatetime, ocrFromName,
    showDonationPrompt, donationEntering, donationAmt, donationDt,
  };

  const processScreenshotFile = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const result = reader.result;
      const base64 = result.split(',')[1];
      setLeadScreenshot({ base64, mime: file.type });
      setScreenshotPreview(result);
      setOcrLoading(true);
      try {
        const { upiTransactionId, transactionDatetime, amount, fromName } = await extractTransactionData(result);
        if (upiTransactionId) setUpiTransactionId(upiTransactionId);
        if (transactionDatetime) {
          const dt = new Date(transactionDatetime);
          if (!isNaN(dt.getTime())) {
            setTransactionDatetime(dt.toISOString().slice(0, 16));
          }
        }
        if (amount) setLeadAmount(prev => prev || amount);
        if (fromName) setOcrFromName(fromName);
      } catch (e) { console.error('Error:', e.message); }
      setOcrLoading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleScreenshotChange = (e) => {
    processScreenshotFile(e.target.files[0]);
  };

  const handlePasteScreenshot = usePasteImage(({ base64, mime, file }) => {
    setLeadScreenshot({ base64, mime });
    const reader = new FileReader();
    reader.onload = async () => {
      setScreenshotPreview(reader.result);
      setOcrLoading(true);
      try {
        const { upiTransactionId, transactionDatetime, amount, fromName } = await extractTransactionData(reader.result);
        if (upiTransactionId) setUpiTransactionId(upiTransactionId);
        if (transactionDatetime) {
          const dt = new Date(transactionDatetime);
          if (!isNaN(dt.getTime())) setTransactionDatetime(dt.toISOString().slice(0, 16));
        }
        if (amount) setLeadAmount(prev => prev || amount);
        if (fromName) setOcrFromName(fromName);
      } catch (e) { console.error('Error:', e.message); }
      setOcrLoading(false);
    };
    reader.readAsDataURL(file);
  });

  const filterDonations = (list, filter) => {
    if (!list) return [];
    if (!filter || filter === 'all') return list;
    const now = new Date();
    if (filter === 'monthly') {
      const ym = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
      return list.filter(d => d.date && String(d.date).slice(0, 7) === ym);
    }
    if (filter === 'yearly') {
      return list.filter(d => d.date && new Date(d.date).getFullYear() === now.getFullYear());
    }
    if (filter.startsWith('year_')) {
      const y = Number(filter.split('_')[1]);
      return list.filter(d => d.date && new Date(d.date).getFullYear() === y);
    }
    return list;
  };

  const loadDonations = async (period) => {
    if (!donor) return;
    setDonationLoading(true);
    try {
      const data = await getDonorDonations(donor.id, donor.ngo_id, period || 'all');
      setDonations(Array.isArray(data) ? data : []);
    } catch (err) {
      setDonations([]);
    } finally {
      setDonationLoading(false);
    }
  };

  const openDonationModal = () => {
    setShowDonationModal(true);
    setDonationFilter('all');
    if (donations.length === 0 && !donationLoading) loadDonations('all');
  };

  const handleDonationFilterChange = (filter) => {
    setDonationFilter(filter);
  };

  useEffect(() => {
    if (!donor) return;
    let cancelled = false;
    setDonationLoading(true);
    getDonorDonations(donor.id, donor.ngo_id, 'all')
      .then(data => { if (!cancelled) setDonations(Array.isArray(data) ? data : []); })
      .catch(() => { if (!cancelled) setDonations([]); })
      .finally(() => { if (!cancelled) setDonationLoading(false); });
    return () => { cancelled = true; };
  }, [donor?.id]);

  // Backend-authoritative "next donor": the controlled queue endpoint picks the
  // next donor (order, dedup, current position all live server-side) so the
  // front-end never skips or re-orders a lead on its own. Falls back to the
  // local list so the flow can never dead-end if the queue call fails.
  const goToBackendNext = useCallback(async (priorDonor) => {
    try {
      const cur = await getQueueCurrent(stationOpts(dataTab, selectedStation));
      if (!cur || cur.done || !cur?.donor) {
        setMessage({ type: 'success', text: 'All caught up — every lead here is dispositioned. New leads appear automatically.' });
        return;
      }
      const n = cur.donor;
      const list = donorsRef.current;
      const found = list.findIndex(d => d.id === n.donor_id && d.ngo_id === n.ngo_id);
      if (found >= 0) {
        setIndex(found);
        saveProgress(dataTab, n.donor_id, found);
      } else {
        // Backend chose a donor not in the loaded local list (e.g. another
        // station/tab view) — render it directly as the current card.
        if (priorDonor) setReturnToDonor({ id: priorDonor.id, ngo_id: priorDonor.ngo_id, idx: indexRef.current });
        setExternalDonor(n);
      }
    } catch (err) {
      // Local fallback (proven path) — never dead-end the FRO.
      const nextIdx = findNextDonorIndex(donorsRef.current, priorDonor?.id);
      if (nextIdx >= 0 && donorsRef.current[nextIdx]) {
        setIndex(nextIdx);
        saveProgress(dataTab, donorsRef.current[nextIdx].id, nextIdx);
      } else {
        setMessage({ type: 'success', text: 'All caught up — every lead here is dispositioned. New leads appear automatically.' });
      }
    }
  }, [dataTab, selectedStation, selectedNgo]);

  const handleSave = async () => {
    if (!selected) { setMessage({ type: 'error', text: 'Select a disposition' }); return; }
    if (selected === OTHERS_ID && !((notes || '').trim() || (leadRemark || '').trim())) {
      setRemarkError(true);
      setShowRemark(true);
      setMessage({ type: 'error', text: 'Add a remark for Others before saving.' });
      return;
    }
    if (SCHEDULE_DATE_TYPES.has(selected) && (!scheduledDate || !scheduledTime)) { setMessage({ type: 'error', text: 'Select date & time' }); return; }
    if (SCHEDULE_TIME_TYPES.has(selected) && !callbackTime) { setMessage({ type: 'error', text: 'Select time for callback' }); return; }
    if ((selected === 'lead_done' || selected === 'done') && (!leadAmount || isNaN(leadAmount) || Number(leadAmount) <= 0)) { setMessage({ type: 'error', text: 'Enter a valid payment amount' }); return; }
    if (savingRef.current) return;
    savingRef.current = true;

    setSaving(true); setMessage(null);
    // Close the 4-minute window at submit time rather than when the response
    // lands, so a dropped connection can't leave the FRO watching a live
    // countdown for a disposition they already recorded. saved.timer below
    // overwrites this with the server's authoritative value.
    adoptOptimisticDisposition();
    try {
      const logData = {
        action: 'disposition',
        disposition_category: effCategory,
        disposition_detail: selected,
        notes: notes || null,
        remark: leadRemark || null,
        ngo_id: donor.ngo_id,
      };
      if (SCHEDULE_DATE_TYPES.has(selected)) logData.scheduled_at = istDateTimeToIso(scheduledDate, scheduledTime);
      if (SCHEDULE_TIME_TYPES.has(selected)) {
        const todayIst = istDateString();
        logData.scheduled_at = istDateTimeToIso(todayIst, callbackTime);
      }
      if (selected === 'lead_done') {
        if (leadScreenshot) {
          const uploadResult = await uploadPaymentScreenshot(leadScreenshot.base64, leadScreenshot.mime, { timeout: SAVE_TIMEOUT_MS });
          logData.payment_screenshot_url = uploadResult.file_url;
        }
        logData.donor_address = leadAddress || null;
        logData.pan_number = leadPan || null;
        logData.donor_dob = leadDob || null;
        logData.project_name = projectName || null;
        logData.amount_collected = leadAmount !== '' ? Number(leadAmount) : null;
        logData.upi_transaction_id = upiTransactionId || null;
        logData.transaction_datetime = transactionDatetime ? new Date(transactionDatetime).toISOString() : null;
      }
      if (selected === 'done') {
        logData.amount_collected = leadAmount !== '' ? Number(leadAmount) : null;
      }
      // Suppress realtime-triggered reloads BEFORE the log is written so the
      // INSERT produced by this log's findOrCreateAssignment is always ignored —
      // the local list removal below is authoritative and a mid-save reload must
      // never refetch/re-sort the list and snap the "#N of M" position.
      suppressRealtimeUntilRef.current = Date.now() + 10000;
      if (debounceReloadRef.current) { clearTimeout(debounceReloadRef.current); debounceReloadRef.current = null; }

      const saved = await addDonorLog(donor.id, logData, { timeout: SAVE_TIMEOUT_MS });
      // Same as the donation path: take the server's deadline now rather than
      // letting the countdown show stale seconds until the next heartbeat.
      if (saved?.timer) adoptTimer(saved.timer);
      noteDispositionSaved();
      // A disposition changes what a search should return for that donor, and the
      // server cache is already dropped by invalidateFroCaches() — so the browser
      // memo has to go with it. Without this, re-searching the same term inside
      // the 30s TTL would still show the lead the FRO just closed.
      searchCacheRef.current.clear();
      // The lead the FRO just worked belongs in History now; refetch it so the
      // tab and its badge are current the moment they look.
      setHistoryRefresh(k => k + 1);
      if (selected && isOnCall && activeCall?.donorId === donor.id) endCall();

      // Same-day suppression (backend-authoritative): a donor with ANY
      // disposition today for this worker cannot be returned by /queue/current
      // again today — even for a retryable (ringing/busy) disposition. The
      // backend is the source of truth; here we just drop the just-worked lead
      // from the local list as UX protection so stale UI can never re-show it.
      // It becomes eligible again tomorrow per the existing retry rules.
      // Remove the just-worked lead locally (backend already enforces same-day
      // suppression; this is UX so stale UI can never re-show it today).
      const newDonors = filterAndSortDonors(donorsRef.current.filter(d => !(d.id === donor.id && d.ngo_id === donor.ngo_id)));
      setDonors(newDonors);

      // No auto-advance: in the list flow we return to the list after saving.
      // The FRO explicitly opens their next lead. There is no wrap / re-select,
      // so a just-dispositioned donor cannot reappear.
      setResumeTo(null);
      setReturnToDonor(null);
      if (activeDonor) {
        setActiveDonor(null);
        reloadDonors();
      }
      setExternalDonor(null);
      // Drop the just-worked lead from Overdue / Follow-Up lists instantly —
      // a changed disposition must never linger there, no matter what the
      // next server refetch returns. The refetch below reconciles after.
      const sameLead = (d) => d && d.id === donor.id
        && (d.ngo_id == null || donor.ngo_id == null || d.ngo_id === donor.ngo_id);
      setOverdueLeads((prev) => (Array.isArray(prev) ? prev.filter((d) => !sameLead(d)) : prev));
      setFollowUps((prev) => (Array.isArray(prev) ? prev.filter((d) => !sameLead(d)) : prev));
      if (listView === 'overdue') {
        getOverdue()
          .then((list) => setOverdueLeads(list || []))
          .catch(() => {});
      }
      clearFormState();
    } catch (err) {
      setMessage({ type: 'error', text: err.message });
    } finally { setSaving(false); savingRef.current = false; }
  };

  const handleSearch = (q) => {
    setSearchQuery(q);
    if (backendSearchTimerRef.current) { clearTimeout(backendSearchTimerRef.current); backendSearchTimerRef.current = null; }
    const term = q.trim();
    latestSearchRef.current = term;
    // Every backend search is expensive: the handler materialises every in-scope
    // donor id, then runs a leading-wildcard ILIKE across it. Typing a 10-digit
    // number one key at a time used to fire roughly one such query per keystroke,
    // because the 300ms debounce elapsed faster than a person types. Two changes
    // collapse that:
    //   - SEARCH_DEBOUNCE_MS now exceeds a normal inter-keystroke gap, so the
    //     timer is repeatedly reset and only fires once typing actually stops.
    //   - a bare-digit term (a phone number, the common case) must reach
    //     SEARCH_MIN_DIGITS before any request is made. Partial numbers almost
    //     never identify a donor and each one was a wasted full-scope scan.
    // Alpha terms keep the lower 2-character floor, where a prefix is genuinely
    // useful.
    const isNumeric = /^\d+$/.test(term);
    const minChars = isNumeric ? SEARCH_MIN_DIGITS : SEARCH_MIN_CHARS;
    if (term.length < minChars) {
      setDisposedResults([]);
      return;
    }
    // Cache is keyed by the term AND the scope it was searched under: the same
    // number means different donors at a different station, so reusing a result
    // across stations would show leads the FRO is not viewing.
    const scopeKey = `${selectedStation && selectedStation !== 'all' ? selectedStation : 'all'}|${selectedNgo || 'all'}`;
    const cacheKey = `${scopeKey}::${term.toLowerCase()}`;
    const hit = searchCacheRef.current.get(cacheKey);
    if (hit && Date.now() - hit.at < SEARCH_CACHE_TTL_MS) {
      setDisposedResults(hit.v);
      return;
    }
    backendSearchTimerRef.current = setTimeout(async () => {
      // A request for this exact key may already be in flight (typing fast, then
      // backspacing into a term that was just queried). Reuse it instead of
      // issuing a duplicate.
      const pending = searchInflightRef.current.get(cacheKey);
      if (pending) { pending.then((v) => setDisposedResults(v)).catch(() => setDisposedResults([])); return; }
      setDisposedSearchLoading(true);
      const request = (async () => {
        // Search the station the FRO is currently viewing (active + already
        // dispositioned). Previously this spanned EVERY station the FRO holds,
        // so a FRO on AOD-7 was shown AOD-5 donors — the single biggest source
        // of "this donor is on the wrong station" reports.
        const results = await searchDonorsByMobile(term, {
          station: selectedStation && selectedStation !== 'all' ? selectedStation : undefined,
          ngoId: selectedNgo || undefined,
        });
        const value = results || [];
        searchCacheRef.current.set(cacheKey, { v: value, at: Date.now() });
        // Bound the map: an FRO session should not accumulate every prefix they
        // ever typed.
        if (searchCacheRef.current.size > SEARCH_CACHE_MAX) {
          const oldest = searchCacheRef.current.keys().next().value;
          searchCacheRef.current.delete(oldest);
        }
        return value;
      })();
      searchInflightRef.current.set(cacheKey, request);
      try {
        const value = await request;
        // Responses can land out of order — a slow early query must not overwrite
        // the results of a term the FRO has since finished typing. Drop anything
        // that no longer matches what is in the box.
        if (latestSearchRef.current === term) setDisposedResults(value);
      } catch {
        if (latestSearchRef.current === term) setDisposedResults([]);
      } finally {
        searchInflightRef.current.delete(cacheKey);
        setDisposedSearchLoading(false);
      }
    }, SEARCH_DEBOUNCE_MS);
  };

  const handleButtonClick = () => {
    if (selected) { handleSave(); return; }
    if (externalDonor) {
      setResumeTo(null);
      const backIdx = returnToDonor?.idx ?? 0;
      const backDonor = donors[backIdx];
      setExternalDonor(null);
      setReturnToDonor(null);
      setIndex(backIdx);
      if (backDonor) saveProgress(dataTab, backDonor.id, backIdx);
      return;
    }
    if (returnToDonor) {
      setResumeTo(null);
      setIndex(returnToDonor.idx);
      setReturnToDonor(null);
      return;
    }
    if (resumeTo) {
      const ridx = donors.findIndex(d => d.id === resumeTo.id && d.ngo_id === resumeTo.ngo_id);
      setResumeTo(null);
      if (ridx >= 0) {
        setIndex(ridx);
        saveProgress(dataTab, donors[ridx].id, ridx);
        return;
      }
    }
    const nextIdx = findNextDonorIndex(donors, donor.id);
    if (nextIdx < 0 || nextIdx === index || !donors[nextIdx]) {
      setMessage({ type: 'error', text: 'No more donors' });
      return;
    }
    if (donor && nextIdx < index) setResumeTo({ id: donor.id, ngo_id: donor.ngo_id });
    setIndex(nextIdx);
    saveProgress(dataTab, donors[nextIdx].id, nextIdx);
  };

  const fmt = callFmt

  const visibleDonations = filterDonations(donations, donationFilter);
  const yearOptions = [...new Set(
    donations.map(d => d.date ? new Date(d.date).getFullYear() : null).filter(Boolean)
  )].sort((a, b) => b - a);
  const allYears = yearOptions.length > 0 ? yearOptions : (() => {
    const y = new Date().getFullYear();
    return [y, y - 1, y - 2, y - 3, y - 4, y - 5];
  })();

  // NOTE: the `loading` early-return was removed so the filter bar stays
  // mounted while the queue loads. Skeleton rows render in the list area below
  // instead of blanking out the entire panel (which made the filters "flicker
  // in" after load and looked like they were still loading).
  //
  // Same rule for an empty queue: we never unmount the filter bar / Leads |
  // Follow Ups | History tabs — the "no data allotted" card lives in the list
  // area so the FRO can still switch tabs and work History or Follow Ups.

  const timelineIcon = (log) => {
    if (log.action === 'disposition') return log.disposition_category === 'connected' ? 'check_circle' : 'cancel';
    const map = { call: 'call', visit: 'home', message: 'mail', follow_up: 'history', donation: 'payments', note: 'note', month_reset: 'restart_alt' };
    return map[log.action] || 'circle';
  };

  const formatTime = (d) => new Date(d).toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).toUpperCase();

  const logDate = (log) => (log.action === 'donation' || (log.disposition_detail === 'lead_done' && log.accounts_status === 'verified'))
    ? (log.transaction_datetime || log.verified_at || log.created_at)
    : log.created_at;

  const statusPill = (status) => {
    const label = status ? status.replace(/_/g, ' ') : 'unknown';
    return <span className={`pill ${STATUS_PILL_MAP[status] || 'pill-gray'}`}>{label}</span>;
  };

  // ─────────────────────────── MY LEADS — LIST VIEW ─────────────────────────
  // Shown by default. Every lead row is fully visible (name/mobile) and
  // clickable in both the New and Old tabs — the old "first row unlocked, rest
  // masked + locked" model has been removed so the FRO can scan all their
  // leads. After a lead is dispositioned it is removed from the list. Typing in
  // the search bar swaps in read-only results across the FRO's whole station
  // scope (active + already dispositioned leads).
  if (!activeDonor) {
    // NGO / station options derived from the assigned stations.
    const ngoMap = {};
    stations.forEach(st => { if (st.ngo_id && !ngoMap[st.ngo_id]) ngoMap[st.ngo_id] = st.ngo_name || st.ngo_id; });
    const ngoList = Object.entries(ngoMap).map(([id, name]) => ({ ngo_id: id, ngo_name: name }));
    const stationList = stations
      .filter(s => !selectedNgo || s.ngo_id === selectedNgo)
      .reduce((acc, s) => { if (s.station && !acc.includes(s.station)) acc.push(s.station); return acc; }, []);

    // My Leads lists pending work only: filterAndSortDonors drops any lead whose
    // status is not 'pending', so this list agrees with the backend (which now
    // returns only pending rows). Everything already dispositioned this month
    // lives in History / Callbacks / Follow-ups / Overdue, and the monthly
    // rollover brings each lead back here by resetting its status to pending.
    // The status-group dropdown and the "Donated: hidden" toggle were removed
    // because they hid work; the "Hidden: N" toggle below only parks
    // DND / donated-this-month leads, which are no longer in a pending-only
    // list and so effectively show nothing here by design.
    const suppressedCount = donors.filter(d => d.is_suppressed).length;
    const closedCount = donors.filter(d => !d.is_suppressed && d.suppress_reason).length;
    const visible = donors.filter(d => {
      if (!listShowSuppressed && d.is_suppressed) return false;
      return true;
    });

    const isHistory = listView === 'history';
    const isFollowUps = listView === 'followups';
    // Overdue tab: every past-due follow-up/callback/promise, most-overdue first,
    // fetched server-side from next_follow_up so it spans every past day/month.
    const isOverdueTab = listView === 'overdue';
    const overdueList = overdueLeads;
    // In History tab, filter locally; in Leads tab searching swaps queue for disposed search results
    const searching = listView === 'leads' && searchQuery.trim().length >= 2;
    const historyFiltered = isHistory ? historyLeads.filter(d => {
      const q = searchQuery.trim().toLowerCase();
      if (!q) return true;
      return (d.donor_name || '').toLowerCase().includes(q)
        || (d.donor_mobile || '').includes(q)
        || (d.disposition_detail || '').toLowerCase().includes(q)
        || (d.station || '').toLowerCase().includes(q);
    }) : [];
    const followUpFiltered = isFollowUps ? followUps.filter(d => {
      const q = searchQuery.trim().toLowerCase();
      if (!q) return true;
      return (d.donor_name || '').toLowerCase().includes(q)
        || (d.donor_mobile || '').includes(q);
    }) : [];
    // Follow Up tab = FRESH follows only: no due time yet, or the given time is
    // still ahead. Once that time passes the lead moves to Overdue; if it is
    // re-logged with a new follow-up it comes back here and leaves Overdue.
    const followUpActive = isFollowUps ? followUpFiltered.filter(d => {
      const t = d.due_date || d.scheduled_at;
      return !t || new Date(t).getTime() >= Date.now();
    }) : [];
    const overdueFiltered = isOverdueTab ? overdueList.filter(d => {
      const q = searchQuery.trim().toLowerCase();
      if (!q) return true;
      return (d.donor_name || '').toLowerCase().includes(q)
        || (d.donor_mobile || '').includes(q);
    }) : [];
    const listItems = isHistory ? historyFiltered.map(r => ({
      ...r,
      id: r.donor_id,
      is_disposed: true,
    })) : isOverdueTab ? overdueFiltered : isFollowUps ? followUpActive : (searching ? disposedResults.map(r => ({
      ...r,
      id: r.donor_id,
      ngo_id: r.ngo_id,
      donor_name: r.donor_name,
      donor_mobile: r.donor_mobile,
      station: r.station,
      is_disposed: !!r.disposed_at || r.status === 'disposed',
      disposition_detail: r.disposition_detail,
      disposed_at: r.disposed_at,
    })) : visible);

    // Only the first `visibleCount` rows are mounted. `hasMoreRef` is read by the
    // scroll handler above to decide whether the window can still grow.
    const renderedItems = listItems.slice(0, visibleCount);
    hasMoreRef.current = renderedItems.length < listItems.length;

    const openLead = (d) => {
      if (isHistory || isFollowUps || isOverdueTab) {
        if (listScrollRef.current) savedListScrollRef.current = listScrollRef.current.scrollTop;
        setActiveDonor({ ...d, _fromList: listView });
        setSelected(null); setNotes(''); setLeadAmount('');
        return;
      }
      // Search results can be opened to view/update the lead. When a hit also
      // exists in the current live queue, snap to that exact donor so the detail
      // panel receives the full (live) record; otherwise render the result record.
      const keyed = searching
        ? donors.find(x => x.id === d.id && x.ngo_id === d.ngo_id)
        : null;
      const found = donors.findIndex(x => x.id === d.id && x.ngo_id === d.ngo_id);
      if (found >= 0) setIndex(found);
      // Remember where the FRO was before opening the lead so going back (or
      // disposing) returns them to the same spot instead of the top of the list.
      if (listScrollRef.current) savedListScrollRef.current = listScrollRef.current.scrollTop;
      setActiveDonor(keyed || d);
      setSelected(null); setNotes(''); setLeadAmount('');
    };

    return (
      <div className="detail-card" style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', ...(embedded ? { border: 'none' } : {}) }}>
        {/* Filter bar */}
        <div style={{ padding: isCompact ? '10px 10px 6px' : '14px 18px 8px', flexShrink: 0 }}>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <div style={{ display: 'inline-flex', background: 'var(--bg)', border: '1px solid var(--line)', borderRadius: 10, padding: 3 }}>
              <button onClick={() => setListView('leads')}
                style={{ padding: '6px 12px', borderRadius: 10, border: 'none', fontFamily: 'inherit', fontSize: 11, fontWeight: 700, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 5, whiteSpace: 'nowrap', background: listView === 'leads' ? 'var(--sage)' : 'transparent', color: listView === 'leads' ? '#fff' : 'var(--ink-soft)', boxShadow: listView === 'leads' ? '0 1px 4px rgba(0,0,0,.18)' : 'none', transition: 'all .15s' }}>
                Leads
                {total ? <span style={{ minWidth: 16, padding: '0 4px', borderRadius: 999, fontSize: 9, fontWeight: 700, background: listView === 'leads' ? 'rgba(255,255,255,.22)' : 'var(--line)', color: listView === 'leads' ? '#fff' : 'var(--ink-soft)' }}>{total}</span> : null}
              </button>
              <button onClick={() => setListView('followups')}
                style={{ padding: '6px 12px', borderRadius: 10, border: 'none', fontFamily: 'inherit', fontSize: 11, fontWeight: 700, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 5, whiteSpace: 'nowrap', background: listView === 'followups' ? 'var(--sage)' : 'transparent', color: listView === 'followups' ? '#fff' : 'var(--ink-soft)', boxShadow: listView === 'followups' ? '0 1px 4px rgba(0,0,0,.18)' : 'none', transition: 'all .15s' }}>
                Follow Ups
                {followUpActive.length ? <span style={{ minWidth: 16, padding: '0 4px', borderRadius: 999, fontSize: 9, fontWeight: 700, background: listView === 'followups' ? 'rgba(255,255,255,.22)' : 'var(--line)', color: listView === 'followups' ? '#fff' : 'var(--ink-soft)' }}>{followUpActive.length}</span> : null}
              </button>
              <button onClick={() => setListView('overdue')}
                style={{ padding: '6px 12px', borderRadius: 10, border: 'none', fontFamily: 'inherit', fontSize: 11, fontWeight: 700, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 5, whiteSpace: 'nowrap', background: isOverdueTab ? 'var(--sage)' : 'transparent', color: isOverdueTab ? '#fff' : 'var(--ink-soft)', boxShadow: isOverdueTab ? '0 1px 4px rgba(0,0,0,.18)' : 'none', transition: 'all .15s' }}>
                Overdue
                {overdueList.length ? <span style={{ minWidth: 16, padding: '0 4px', borderRadius: 999, fontSize: 9, fontWeight: 700, background: isOverdueTab ? 'rgba(255,255,255,.22)' : '#fee2e2', color: isOverdueTab ? '#fff' : '#b91c1c' }}>{overdueList.length}</span> : null}
              </button>
              <button onClick={() => setListView('history')}
                style={{ padding: '6px 12px', borderRadius: 10, border: 'none', fontFamily: 'inherit', fontSize: 11, fontWeight: 700, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 5, whiteSpace: 'nowrap', background: listView === 'history' ? 'var(--sage)' : 'transparent', color: listView === 'history' ? '#fff' : 'var(--ink-soft)', boxShadow: listView === 'history' ? '0 1px 4px rgba(0,0,0,.18)' : 'none', transition: 'all .15s' }}>
                History
                {historyLeads.length ? <span style={{ minWidth: 16, padding: '0 4px', borderRadius: 999, fontSize: 9, fontWeight: 700, background: listView === 'history' ? 'rgba(255,255,255,.22)' : 'var(--line)', color: listView === 'history' ? '#fff' : 'var(--ink-soft)' }}>{historyLeads.length}</span> : null}
              </button>
            </div>
            {listView === 'leads' && (
              <div style={{ display: 'inline-flex', background: 'var(--bg)', border: '1px solid var(--line)', borderRadius: 10, padding: 3 }}>
                <button onClick={() => switchTab('new')}
                  style={{ padding: '6px 12px', borderRadius: 10, border: 'none', fontFamily: 'inherit', fontSize: 11, fontWeight: 700, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 5, whiteSpace: 'nowrap', background: dataTab === 'new' ? 'var(--sage)' : 'transparent', color: dataTab === 'new' ? '#fff' : 'var(--ink-soft)', boxShadow: dataTab === 'new' ? '0 1px 4px rgba(0,0,0,.18)' : 'none', transition: 'all .15s' }}>
                  New
                </button>
                <button onClick={() => switchTab('old')}
                  style={{ padding: '6px 12px', borderRadius: 10, border: 'none', fontFamily: 'inherit', fontSize: 11, fontWeight: 700, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 5, whiteSpace: 'nowrap', background: dataTab === 'old' ? 'var(--sage)' : 'transparent', color: dataTab === 'old' ? '#fff' : 'var(--ink-soft)', boxShadow: dataTab === 'old' ? '0 1px 4px rgba(0,0,0,.18)' : 'none', transition: 'all .15s' }}>
                  Old
                </button>
              </div>
            )}
            <select value={selectedNgo || ''} onChange={e => { setSelectedNgo(e.target.value || null); setSelectedStation('all'); }}
              style={{ padding: '6px 12px', borderRadius: 10, border: '1px solid var(--line)', fontFamily: 'inherit', fontSize: 11, fontWeight: 600, cursor: 'pointer', background: selectedNgo ? 'var(--sage)' : 'var(--bg)', color: selectedNgo ? '#fff' : 'var(--ink-soft)', outline: 'none' }}>
              <option value="" style={{ color: 'var(--ink)' }}>All NGOs</option>
              {ngoList.map(n => <option key={n.ngo_id} value={n.ngo_id} style={{ color: 'var(--ink)' }}>{n.ngo_name}</option>)}
            </select>
            <select value={selectedStation || 'all'} onChange={e => setSelectedStation(e.target.value || 'all')}
              style={{ padding: '6px 12px', borderRadius: 10, border: '1px solid var(--line)', fontFamily: 'inherit', fontSize: 11, fontWeight: 600, cursor: 'pointer', background: selectedStation && selectedStation !== 'all' ? 'var(--sage)' : 'var(--bg)', color: selectedStation && selectedStation !== 'all' ? '#fff' : 'var(--ink-soft)', outline: 'none' }}>
              <option value="all" style={{ color: 'var(--ink)' }}>All stations</option>
              {stationList.map(s => <option key={s} value={s} style={{ color: 'var(--ink)' }}>{s}</option>)}
            </select>
            {listView === 'leads' && (
              <button onClick={() => setListShowSuppressed(v => !v)}
                title={listShowSuppressed
                  ? 'Hide leads held back (DND, donated this month)'
                  : `Show the ${suppressedCount} leads held back (DND, donated this month)`}
                style={{ padding: '6px 12px', borderRadius: 10, border: '1px solid var(--line)', fontFamily: 'inherit', fontSize: 11, fontWeight: 600, cursor: 'pointer', background: listShowSuppressed ? 'var(--sage)' : 'var(--bg)', color: listShowSuppressed ? '#fff' : 'var(--ink-soft)', outline: 'none' }}>
                {listShowSuppressed ? 'Showing all leads' : `Hidden: ${suppressedCount}`}
              </button>
            )}
          </div>

          <div style={{ position: 'relative', marginTop: 10 }}>
            <span className="material-symbols-outlined" style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', fontSize: 14, color: 'var(--ink-soft)' }}>search</span>
            <input
              type="text"
              value={searchQuery}
              onChange={e => handleSearch(e.target.value)}
              placeholder="Search name or mobile..."
              style={{ width: '100%', padding: '8px 12px 8px 32px', border: '1px solid var(--line)', borderRadius: 10, background: 'var(--card-bg)', fontSize: 12, fontFamily: 'inherit', outline: 'none', color: 'var(--ink)', boxSizing: 'border-box' }}
            />
            {searchQuery && (
              <span className="material-symbols-outlined" style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', fontSize: 13, color: 'var(--ink-soft)', cursor: 'pointer' }} onClick={() => { setSearchQuery(''); setDisposedResults([]); }}>close</span>
            )}
          </div>
        </div>

        {message && (
          <div className={`detail-message ${message.type}`} style={{ margin: 8 }}>
            <span className="material-symbols-outlined" style={{ fontSize: 14 }}>{message.type === 'error' ? 'error' : 'check_circle'}</span>
            {message.text}
          </div>
        )}

        {/* List */}
        <div ref={listScrollRef} onScroll={handleListScroll} style={{ flex: 1, minHeight: 0, overflowY: 'auto', padding: isCompact ? '8px 8px' : '10px 12px' }}>
          {isFollowUps && !followUpsLoading && (
            <div style={{ fontSize: 10.5, color: 'var(--ink-soft)', lineHeight: 1.5, padding: '6px 10px', marginBottom: 8, borderRadius: 8, background: 'var(--bg)', border: '1px dashed var(--line)', fontStyle: 'italic' }}>
              Fresh follow-ups you tagged. When a follow-up's given time passes, it moves to Overdue, where you'll see it until re-logged.
            </div>
          )}
          {loading ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="sk" style={{ height: 56, borderRadius: 'var(--radius-sm)' }} />
              ))}
            </div>
          ) : isHistory && historyLoading ? (
            <div style={{ padding: 24, textAlign: 'center', color: 'var(--ink-soft)', fontSize: 12 }}>
              Loading history…
            </div>
          ) : (isFollowUps || isOverdueTab) && followUpsLoading ? (
            <div style={{ padding: 24, textAlign: 'center', color: 'var(--ink-soft)', fontSize: 12 }}>
              Loading…
            </div>
          ) : searching && disposedSearchLoading ? (
            <div style={{ padding: 24, textAlign: 'center', color: 'var(--ink-soft)', fontSize: 12 }}>
              Searching leads…
            </div>
          ) : searching && listItems.length === 0 ? (
            <div style={{ padding: 24, textAlign: 'center', color: 'var(--ink-soft)', fontSize: 12 }}>
              No leads match "{searchQuery.trim()}". Clear the search to return to your queue.
            </div>
          ) : listItems.length === 0 ? (
            listView === 'leads' && donors.length === 0 ? (
              <div className="fro-empty-state" style={{ padding: '34px 20px', marginTop: 4 }}>
                <div className="fro-empty-icon">
                  <span className="material-symbols-outlined" style={{ fontSize: 36, color: 'var(--sage)', opacity: .5 }}>{dataTab === 'new' ? 'fiber_new' : 'history'}</span>
                </div>
                <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 4 }}>No {dataTab === 'new' ? 'new' : 'old'} data allotted</div>
                <div style={{ fontSize: 11, color: 'var(--ink-soft)', maxWidth: 280, textAlign: 'center', lineHeight: 1.5 }}>
                  {stations.length === 0
                    ? 'You are not assigned to any station yet. Ask your Admin to assign you to a station.'
                    : (dataTab === 'new'
                      ? 'New data will appear here once distributed to your station.'
                      : 'Old data will appear here once uploaded to your station.')}
                </div>
                {(autoFallbackAttemptedRef.current) && (
                  <div style={{ fontSize: 11, color: 'var(--ink-soft)', maxWidth: 280, textAlign: 'center', lineHeight: 1.5, marginTop: 4 }}>
                    No new or old data is currently available at your station. Contact your admin if you expect data here.
                  </div>
                )}
                <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                  {dataTab === 'new' ? (
                    <button onClick={() => switchTab('old')} className="fro-empty-switch">
                      <span className="material-symbols-outlined" style={{ fontSize: 13 }}>history</span> Try Old Data tab
                    </button>
                  ) : (
                    <button onClick={() => switchTab('new')} className="fro-empty-switch">
                      <span className="material-symbols-outlined" style={{ fontSize: 13 }}>fiber_new</span> Try New Data tab
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div style={{ padding: 24, textAlign: 'center', color: 'var(--ink-soft)', fontSize: 12 }}>
                {isHistory
                  ? 'No disposed leads yet. Work a lead and it will appear here.'
                  : isOverdueTab
                    ? "No overdue leads — you're all caught up."
                    : isFollowUps
                      ? 'No calls scheduled, no callbacks assigned, no promises to pay yet.'
                      : 'No leads match the current filters.'}
              </div>
            )
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {renderedItems.map((d) => {
                return (
                  <div key={`${d.id || d.donor_id}-${d.ngo_id || ''}`}
                    onClick={() => openLead(d)}
                    onMouseOver={e => { e.currentTarget.style.borderColor = 'var(--sage)'; e.currentTarget.style.boxShadow = '0 4px 14px rgba(0,0,0,.08)'; e.currentTarget.style.transform = 'translateY(-1px)'; }}
                    onMouseOut={e => { e.currentTarget.style.borderColor = 'var(--line)'; e.currentTarget.style.boxShadow = 'var(--shadow)'; e.currentTarget.style.transform = 'none'; }}
                    style={{
                      display: 'flex', alignItems: 'center', gap: isCompact ? 8 : 12,
                      padding: isCompact ? '10px 10px' : '12px 14px',
                      background: 'var(--card-bg)', border: '1px solid var(--line)', borderRadius: 'var(--radius-sm)',
                      boxShadow: 'var(--shadow)', cursor: 'pointer', transition: 'transform .12s, box-shadow .12s, border-color .12s',
                    }}>
                    <div style={{ width: isCompact ? 34 : 40, height: isCompact ? 34 : 40, borderRadius: '50%', background: d.is_disposed ? '#eef2f7' : '#3b82f6', color: d.is_disposed ? '#64748b' : '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: isCompact ? 12 : 14, fontWeight: 700, flexShrink: 0 }}>
                      {initials(d.donor_name || '')}
                    </div>
                    <div style={{ flex: 1, minWidth: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: isCompact ? 6 : 8 }}>
                      <div style={{ minWidth: 0 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                          <span style={{ fontSize: isCompact ? 12.5 : 13, fontWeight: 600, color: 'var(--ink)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{d.donor_name || 'Unknown'}</span>
                          {d.is_new && (
                            <span style={{ flexShrink: 0, padding: '1px 6px', borderRadius: 999, background: '#16a34a', color: '#fff', fontSize: isCompact ? 8 : 9, fontWeight: 700 }}>NEW</span>
                          )}
                        </div>
                        <div style={{ fontSize: 11, color: 'var(--ink-soft)', marginTop: 2, display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                          <span style={{ fontWeight: 600, color: 'var(--ink)' }}>{d.donor_mobile || '—'}</span>
                          {d.owner_name && (
                            <span style={{ padding: '1px 7px', borderRadius: 6, fontSize: 10, fontWeight: 700, background: '#e0e7ff', color: '#4338ca' }}>{d.owner_name}</span>
                          )}
                          {d.ngo_name && (
                            <span style={{ padding: '1px 7px', borderRadius: 6, fontSize: 10, fontWeight: 700, background: '#5B6B4E1A', color: '#5B6B4E' }}>{d.ngo_name}</span>
                          )}
                          {d.ngo_names && d.ngo_names.length > 0 && (
                            <>
                              <span style={{ color: 'var(--line)' }}>•</span>
                              {d.ngo_names.map((n, idx) => (
                                <span key={idx} style={{ padding: '1px 7px', borderRadius: 6, fontSize: 10, fontWeight: 700, background: '#5B6B4E1A', color: '#5B6B4E' }}>{n}</span>
                              ))}
                            </>
                          )}
                        </div>
                        <div style={{ fontSize: 11, color: 'var(--ink-soft)', marginTop: 2 }}>{d.station || '—'}</div>
                      </div>
                      <div style={{ flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 3 }}>
                        {d.type ? (
                          <>
                            <span style={{ padding: `1px 7px`, borderRadius: 999, fontSize: 9, fontWeight: 700, whiteSpace: 'nowrap', background: d.type === 'promise' ? '#ede9fe' : d.type === 'callback' ? '#dbeafe' : '#dcfce7', color: d.type === 'promise' ? '#7e22ce' : d.type === 'callback' ? '#1d4ed8' : '#166534' }}>
                              {d.type === 'promise' ? 'PROMISE' : d.type === 'callback' ? 'CALLBACK' : 'FOLLOW UP'}
                            </span>
                            {d.scheduled_at && <span style={{ fontSize: 9, color: d.is_overdue ? '#b91c1c' : 'var(--ink-soft)', fontWeight: d.is_overdue ? 800 : 400, whiteSpace: 'nowrap' }}>{new Date(d.scheduled_at).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>}
                            {d.is_overdue && (
                              <span style={{ padding: '2px 7px', borderRadius: 999, fontSize: 8.5, fontWeight: 800, whiteSpace: 'nowrap', background: '#dc2626', color: '#fff' }}>
                                OVERDUE
                              </span>
                            )}
                          </>
                        ) : d.is_disposed ? (
                          <>
                            {statusPill(d.disposition_detail || 'disposed')}
                            {d.disposed_at && <span style={{ fontSize: 9, color: 'var(--ink-soft)' }}>{new Date(d.disposed_at).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>}
                          </>
                        ) : statusPill(d.status)}
                        {/* Month-boundary context: this lead was worked before and
                            the rollover sent it back to pending, from the status
                            shown. Cleared once the FRO works it again. */}
                        {!d.is_disposed && d.rollover_from_status && (
                          <span title={`Monthly reset from ${String(d.rollover_from_status).replace(/_/g, ' ')}`}
                            style={{ padding: '2px 7px', borderRadius: 999, fontSize: 8.5, fontWeight: 800, whiteSpace: 'nowrap', background: '#eef2ff', color: '#4338ca' }}>
                            ↺ {String(d.rollover_from_status).replace(/_/g, ' ')}
                          </span>
                        )}
                        {/* Why this lead is held back, so "why isn't this in my
                            list?" is always answerable on the row itself. */}
                        {d.suppress_reason && (
                          <span
                            title={SUPPRESS_REASON_LABELS[d.suppress_reason] || d.suppress_reason}
                            style={{
                              padding: '2px 7px', borderRadius: 999, fontSize: 8.5, fontWeight: 800, whiteSpace: 'nowrap',
                              background: d.suppress_reason === 'dnd' ? '#fee2e2' : d.is_suppressed ? '#fef3c7' : '#f1f5f9',
                              color: d.suppress_reason === 'dnd' ? '#b91c1c' : d.is_suppressed ? '#92400e' : '#64748b',
                            }}>
                            {d.suppress_reason === 'dnd' ? 'DND'
                              : d.suppress_reason === 'donated_this_month' ? 'DONATED'
                                : d.suppress_reason === 'disposed_today' ? 'DONE TODAY'
                                  : 'CLOSED'}
                          </span>
                        )}
                      </div>
                    </div>
                    <span className="material-symbols-outlined" style={{ fontSize: isCompact ? 15 : 16, color: 'var(--sage)', flexShrink: 0 }}>chevron_right</span>
                  </div>
                );
              })}
              {hasMoreRef.current ? (
                // More leads are below the fold; keep a light anchor row so the
                // scrollbar reflects the true list length and the next page loads
                // the moment this row enters view.
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6, paddingTop: 2 }}>
                  <div className="sk" style={{ height: 56, borderRadius: 'var(--radius-sm)' }} />
                  <div style={{ fontSize: 10, color: 'var(--ink-soft)', textAlign: 'center' }}>
                    Scroll for more · {listItems.length - renderedItems.length} remaining
                  </div>
                </div>
              ) : renderedItems.length > LEADS_PAGE_SIZE ? (
                <div style={{ fontSize: 10, color: 'var(--ink-soft)', textAlign: 'center', paddingTop: 4 }}>
                  All {renderedItems.length} shown
                </div>
              ) : null}
            </div>
          )}
        </div>
        <div style={{ padding: '8px 14px', borderTop: '1px solid var(--line)', fontSize: 10, color: 'var(--ink-soft)' }}>
          {loading
            ? 'Loading leads…'
            : isHistory
              ? `Showing ${renderedItems.length} of ${listItems.length} disposed lead(s)${searchQuery.trim() ? ' found' : ''}`
              : isOverdueTab
                ? `Showing ${renderedItems.length} of ${listItems.length} overdue lead(s)${searchQuery.trim() ? ' found' : ''}`
                : isFollowUps
                  ? `Showing ${renderedItems.length} of ${listItems.length} follow-up(s)${searchQuery.trim() ? ' found' : ''}`
                : searching
                  ? `Showing ${renderedItems.length} of ${listItems.length} lead(s) found`
                  : `Showing ${renderedItems.length} of ${total || donors.length} allotted leads (total: ${total || donors.length})`
                    + (hasMoreRef.current ? ' · scroll for more' : ' ( total) · all shown')
                    + (closedCount ? ` · ${closedCount} already worked — filter by status` : '')
                    + (suppressedCount ? ` \u00b7 ${suppressedCount} held back (DND, donated this month) \u2014 use "Hidden: ${suppressedCount}" to view` : '')}
        </div>
      </div>
    );
  }

  const detailTree = (
    <div style={embedded
      ? { position: 'absolute', inset: 0, zIndex: 1400, background: 'var(--bg)', display: 'flex', flexDirection: 'column', padding: '4px 10px 10px' }
      : { flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
    <div className="detail-card" style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
      <div className="detail-split">
        {/* LEFT PANEL — merged profile + details */}
        <div className="detail-left" style={{ padding: '12px 0 12px 12px' }}>
          <div className="detail-card" style={{ flex: '1 1 0%', minHeight: 0 }}>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
            {/* Profile header */}
            <div style={{ textAlign: 'center', paddingTop: 12, paddingBottom: 10, borderBottom: '1px solid var(--line)', flexShrink: 0 }}>
              <div className="detail-avatar">{initials(donor.donor_name)}</div>
              <div className="detail-name">{donor.donor_name}</div>
              <div className="fro-donor-position">#{index + 1} of {total || donors.length}</div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, flexWrap: 'wrap', marginTop: 4 }}>
                  {donor.is_new && (
                    <span style={{ padding: '1px 6px', borderRadius: 4, background: '#16a34a', color: '#fff', fontSize: 9, fontWeight: 700, letterSpacing: .5 }}>NEW</span>
                  )}
                  {dataTab === 'old' && (
                    <span style={{ padding: '1px 6px', borderRadius: 4, background: '#7c3aed', color: '#fff', fontSize: 9, fontWeight: 700, letterSpacing: .5 }}>OLD</span>
                  )}
                {statusPill(donor.status || 'pending')}
                {donor.rollover_from_status && (
                  <span title={`Monthly reset from ${String(donor.rollover_from_status).replace(/_/g, ' ')}${donor.rollover_at ? ' on ' + new Date(donor.rollover_at).toLocaleDateString('en-GB') : ''}`}
                    style={{ background: '#eef2ff', color: '#4338ca', padding: '1px 7px', borderRadius: 999, fontSize: 8, fontWeight: 700, border: '1px solid #c7d2fe' }}>
                    ↺ was {String(donor.rollover_from_status).replace(/_/g, ' ')}
                  </span>
                )}
                {donor.ngo_name && (
                  <span style={{ background: '#e0e7ff', color: '#4338ca', padding: '1px 7px', borderRadius: 999, fontSize: 8, fontWeight: 700 }}>{donor.ngo_names?.join(', ') || donor.ngo_name}</span>
                )}
                {donor.station && selectedStation === 'all' && (
                  <span style={{ background: '#dbeafe', color: '#1d4ed8', padding: '1px 7px', borderRadius: 999, fontSize: 8, fontWeight: 700, border: '1px solid #93c5fd' }}>{donor.station}</span>
                )}
              </div>
            </div>

            {/* Unified Call + WhatsApp action bar (merged, responsive) */}
            <div style={{ margin: '10px 12px', borderRadius: 12, overflow: 'hidden', display: 'flex', flexDirection: isMobile ? 'column' : 'row' }}>
              {isOnCall && activeCall?.donorId === donor.id ? (
                <button onClick={(e) => { e.stopPropagation(); endCall() }} disabled={saving}
                  style={{ flex: 1, width: '100%', padding: '10px 14px', border: 'none', background: 'linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%)', cursor: saving ? 'not-allowed' : 'pointer', opacity: saving ? .5 : 1, display: 'flex', alignItems: 'center', gap: 8, transition: 'all .15s' }}>
                  <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#dc2626', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <span className="material-symbols-outlined" style={{ fontSize: 16, color: '#fff' }}>call_end</span>
                  </div>
                  <div style={{ flex: 1, textAlign: 'left' }}>
                    <div style={{ fontSize: 10, color: '#991b1b', fontWeight: 500 }}>On Call</div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: '#dc2626', fontVariantNumeric: 'tabular-nums' }}>{callFmt(todayStats?.totalSeconds || 0)}</div>
                  </div>
                </button>
              ) : (
                <div style={{ flex: 1, width: '100%', padding: '10px 14px', background: 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)', display: 'flex', alignItems: 'center', gap: 8, transition: 'all .15s' }}>
                  <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#16a34a', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <span className="material-symbols-outlined" style={{ fontSize: 16, color: '#fff' }}>call</span>
                  </div>
                  <div style={{ flex: 1, textAlign: 'left', minWidth: 0 }}>
                    <div style={{ fontSize: 10, color: '#166534', fontWeight: 500 }}>Call</div>
                    <div style={{ fontSize: 11, color: '#15803d', fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{donor.donor_mobile || 'No number'}</div>
                  </div>
                </div>
              )}
              <button onClick={(e) => { e.stopPropagation(); toast('WhatsApp coming soon', 'info'); }}
                title="WhatsApp (coming soon)"
                style={{ flexShrink: 0, width: isMobile ? '100%' : 64, border: 'none', background: '#25D366', cursor: 'not-allowed', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: isMobile ? 'row' : 'column', gap: 4, padding: isMobile ? '8px 14px' : '10px 6px', opacity: .9, borderLeft: isMobile ? 'none' : '1px solid rgba(255,255,255,.45)', borderTop: isMobile ? '1px solid rgba(255,255,255,.45)' : 'none' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                <span style={{ fontSize: 8, fontWeight: 700, color: '#fff', letterSpacing: .3, lineHeight: 1 }}>WhatsApp</span>
              </button>
            </div>
            {/* Fields */}
            <div className="detail-info-panel" style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div className="detail-field-row">
                <div className="fld">
                  <label>City</label>
                  <div>{donor.donor_city || 'NA'}</div>
                </div>
              </div>
              <div className="detail-field-row">
                <div className="fld">
                  <label>Donor Type {donorTypeSaving && <span style={{ fontSize: 8, opacity: .5 }}>saving…</span>}</label>
                  <select value={donor.donor_type || ''} onChange={handleDonorTypeChange} disabled={donorTypeSaving}>
                    <option value="">— Select —</option>
                    <option value="monthly">Monthly</option>
                    <option value="quarterly">Quarterly</option>
                    <option value="half_yearly">Half-Yearly</option>
                    <option value="yearly">Yearly</option>
                    <option value="one_time">One Time</option>
                  </select>
                  {showDonationPrompt && (
                    <div style={{ marginTop: 8, background: '#f0fdf4', borderRadius: 8, border: '1px solid #bbf7d0', overflow: 'hidden' }}>
                      {!donationEntering ? (
                        <div style={{ padding: '8px 10px' }}>
                          <div style={{ fontSize: 10, fontWeight: 600, color: '#166534', marginBottom: 5 }}>
                            Has this donor donated?
                          </div>
                          <div style={{ display: 'flex', gap: 6 }}>
                            <button onClick={handleDonationYes}
                              style={{ padding: '5px 16px', border: 'none', borderRadius: 5, background: '#16a34a', color: '#fff', fontSize: 10, fontWeight: 700, fontFamily: 'inherit', cursor: 'pointer' }}>
                              Yes
                            </button>
                            <button onClick={handleDonationNo}
                              style={{ padding: '5px 16px', border: '1px solid var(--line)', borderRadius: 5, background: '#fff', color: 'var(--ink)', fontSize: 10, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>
                              No
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div style={{ padding: '8px 10px' }}>
                          <div style={{ fontSize: 10, fontWeight: 600, color: '#166534', marginBottom: 6 }}>
                            Donation Details
                          </div>
                          <div className="detail-field-row" style={{ marginBottom: 4 }}>
                            <div className="fld">
                              <label>Amount (₹)</label>
                              <input type="number" min="0" placeholder="e.g. 5000"
                                value={donationAmt} onChange={e => setDonationAmt(e.target.value)}
                                style={{ width: '100%', boxSizing: 'border-box' }} />
                            </div>
                            <div className="fld">
                              <label>Date</label>
                              <input type="date" value={donationDt} onChange={e => setDonationDt(e.target.value)}
                                style={{ width: '100%', boxSizing: 'border-box' }} />
                            </div>
                          </div>
                          <div style={{ display: 'flex', gap: 4 }}>
                            <button onClick={handleDonationSave} disabled={donationSaving || !donationAmt || !donationDt}
                              style={{ flex: 1, padding: '6px 14px', border: 'none', borderRadius: 5, background: '#16a34a', color: '#fff', fontSize: 10, fontWeight: 700, fontFamily: 'inherit', cursor: donationSaving || !donationAmt || !donationDt ? 'not-allowed' : 'pointer', opacity: donationSaving || !donationAmt || !donationDt ? 0.5 : 1 }}>
                              {donationSaving ? 'Saving...' : 'Save Donation'}
                            </button>
                            {!donationSaving && (
                              <button onClick={() => setDonationEntering(false)}
                                style={{ padding: '5px 10px', border: '1px solid var(--line)', borderRadius: 5, background: '#fff', fontSize: 10, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>
                                Back
                              </button>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
              <div className="detail-field-row">
                <div className="fld">
                  <label>Email</label>
                  <div style={{ fontStyle: donor.donor_email ? 'normal' : 'italic', color: donor.donor_email ? 'inherit' : 'var(--ink-soft)' }}>{donor.donor_email || 'No email'}</div>
                </div>
              </div>
              <div className="detail-field-row">
                <div className="fld">
                  <label>Donations</label>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 3, alignItems: 'stretch' }}>
                    {donationLoading ? (
                      <div style={{ fontSize: 10, color: 'var(--ink-soft)' }}>Loading...</div>
                    ) : donations.length === 0 ? (
                      <div style={{ fontSize: 10, color: 'var(--ink-soft)', fontStyle: 'italic' }}>No donations yet</div>
                    ) : (
                      <>
                        {donations.slice(0, 6).map((d, i) => (
                          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 6, fontSize: 10, padding: '2px 0', borderBottom: '1px dashed var(--line)' }}>
                            <span style={{ flexShrink: 0 }}>{d.date ? new Date(d.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}</span>
                            <span style={{ fontWeight: 600, marginLeft: 'auto' }}>₹{Number(d.amount || 0).toLocaleString('en-IN')}</span>
                            <span className={`bento-pill ${d.status === 'verified' ? 'bento-pill-green' : d.status === 'rejected' ? 'bento-pill-red' : 'bento-pill-yellow'}`} style={{ fontSize: 8, padding: '1px 6px' }}>{d.status || '—'}</span>
                          </div>
                        ))}
                        <button onClick={openDonationModal}
                          style={{ marginTop: 4, alignSelf: 'flex-start', padding: '4px 12px', border: 'none', borderRadius: 5, background: 'var(--sage)', color: '#fff', fontSize: 9, fontWeight: 700, fontFamily: 'inherit', cursor: 'pointer' }}>
                          View All {donations.length > 6 ? `(${donations.length})` : ''}
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
              <div className="detail-field-row">
                <div className="fld">
                  <label>Address</label>
                  <div style={{ fontStyle: detail?.donor_address ? 'normal' : 'italic', color: detail?.donor_address ? 'inherit' : 'var(--ink-soft)' }}>{detail?.donor_address || donor.donor_address || 'No address'}</div>
                </div>
              </div>
              {donor.donor_pan && (
                <div className="detail-field-row">
                  <div className="fld">
                    <label>PAN</label>
                    <div>{donor.donor_pan}</div>
                  </div>
                </div>
              )}
              {donor.donor_dob && (
                <div className="detail-field-row">
                  <div className="fld">
                    <label>DOB</label>
                    <div>{donor.donor_dob}</div>
                  </div>
                </div>
              )}
            </div>

            {/* Status block */}
            {nextSchedule && !nextSchedule.is_completed && (
              <div className="detail-status-block" style={{
                background: new Date(nextSchedule.scheduled_at) < new Date() ? 'var(--md-error-container, #fef2f2)' : '#e0f2fe',
                color: new Date(nextSchedule.scheduled_at) < new Date() ? 'var(--md-error, #dc2626)' : '#0369a1',
                flexShrink: 0, marginTop: 8,
              }}>
                <span className="material-symbols-outlined" style={{ fontSize: 14 }}>{new Date(nextSchedule.scheduled_at) < new Date() ? 'warning' : 'schedule'}</span>
                {new Date(nextSchedule.scheduled_at) < new Date() ? 'Overdue schedule' : 'Next: ' + new Date(nextSchedule.scheduled_at).toLocaleString()}
              </div>
            )}
            {donor.status === 'payment_rejected' && (
              <div className="detail-status-block" style={{ background: 'var(--md-error-container, #fef2f2)', color: 'var(--md-error, #dc2626)', flexShrink: 0, marginTop: 8 }}>
                <span className="material-symbols-outlined" style={{ fontSize: 14 }}>error</span>
                Payment rejected by Accounts
              </div>
            )}
          </div>
          </div>
        </div>

        {/* MIDDLE PANEL — Connection Status first (filters live on the MY LEADS list) */}
        <div className="fro-mid-connection" style={{ paddingTop: 6 }}>
          {message && (
            <div className={`detail-message ${message.type}`}>
              <span className="material-symbols-outlined" style={{ fontSize: 14 }}>{message.type === 'error' ? 'error' : 'check_circle'}</span>
              {message.text}
            </div>
          )}
          {/* Connection Status card */}
          <div className="detail-card" style={{ flex: 1, minHeight: 0 }}>
            {donor.has_donated_current_month ? (
              <DonationDoneStamp donor={donor} />
            ) : (
            <>
            <div className="detail-card-head">Connection Status</div>
            <div className="detail-card-scroll" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div className="detail-dropdown-row">
                <div className="dd">
                  <label>Connected</label>
                  <DispositionDropdown
                    options={CONNECTED_QUICK}
                    value={selected !== null && effCategory === 'connected' ? selected : ''}
                    onChange={id => { if (id) handleDropdownChange(id, 'connected'); }}
                    tone={selected !== null && effCategory === 'connected' ? 'green' : null}
                  />
                </div>
                <div className="dd">
                  <label>Not Connected</label>
                  <DispositionDropdown
                    options={NOT_CONNECTED_QUICK}
                    value={selected !== null && effCategory === 'not_connected' ? selected : ''}
                    onChange={id => { if (id) handleDropdownChange(id, 'not_connected'); }}
                    tone={selected !== null && effCategory === 'not_connected' ? 'red' : null}
                  />
                </div>
              </div>

              {SCHEDULE_DATE_TYPES.has(selected) && (
                <>
                  <div className="detail-field-row">
                    <div className="fld">
                      <label>Follow Up Date</label>
                        <DatePicker value={scheduledDate} onChange={e => { setScheduledDate(e.target.value); setDateConfirmed(true); }} placeholder="Select date" min={(() => { const t = new Date(); t.setDate(t.getDate() + 1); return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`; })()} />
                    </div>
                  </div>
                  {dateConfirmed && (
                    <div className="detail-field-row">
                      <div className="fld">
                        <label>Follow Up Time</label>
                        <TimePicker value={scheduledTime} onChange={e => setScheduledTime(e.target.value)} placeholder="Select time" />
                      </div>
                    </div>
                  )}
                </>
              )}

              {SCHEDULE_TIME_TYPES.has(selected) && (
                <div className="detail-field-row">
                  <div className="fld">
                    <label>Callback Time (Today)</label>
                    <TimePicker value={callbackTime} onChange={e => setCallbackTime(e.target.value)} placeholder="Select time" />
                  </div>
                </div>
              )}

              {selected === 'done' && (
                <div className="detail-field-row">
                  <div className="fld">
                    <label>Amount Collected</label>
                    <input type="number" min="0" value={leadAmount}
                      onChange={e => setLeadAmount(e.target.value)} placeholder="e.g. 5000" />
                  </div>
                </div>
              )}

              {selected === 'lead_done' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div className="detail-field-row">
                    <div className="fld">
                      <label>Project</label>
                      <select value={projectName} onChange={e => setProjectName(e.target.value)}>
                        <option value="">— Select Project —</option>
                        {PROJECTS.map(p => <option key={p} value={p}>{p}</option>)}
                      </select>
                    </div>
                  </div>
                  <div className="detail-field-row">
                    <div className="fld">
                      <label>Amount Collected</label>
                      <input type="number" min="0" value={leadAmount}
                        onChange={e => setLeadAmount(e.target.value)} placeholder="e.g. 5000" />
                    </div>
                  </div>
                  <div className="detail-field-row">
                    <div className="fld">
                      <label>Screenshot / Proof image</label>
                      <label htmlFor="ss-input" className="ss-upload" onPaste={handlePasteScreenshot}
                        title="Upload a file or paste an image (Ctrl+V)">
                        {screenshotPreview ? (
                          <div style={{ position: 'relative' }}>
                            <img src={screenshotPreview} alt="preview" className="ss-preview"
                              onClick={e => { e.preventDefault(); window.open(screenshotPreview, '_blank'); }} />
                            <span className="ss-remove"
                              onClick={e => { e.preventDefault(); setLeadScreenshot(null); setScreenshotPreview(null); document.getElementById('ss-input').value = ''; }}>close</span>
                          </div>
                        ) : (
                          <div className="ss-placeholder">
                            <span className="material-symbols-outlined">upload</span>
                            <span>Upload or paste (Ctrl+V)</span>
                          </div>
                        )}
                      </label>
                      <input id="ss-input" type="file" accept="image/*" onChange={handleScreenshotChange} onPaste={handlePasteScreenshot} />
                    </div>
                  </div>
                  <div className="detail-field-row">
                    <div className="fld">
                      <label>UPI Transaction ID {ocrLoading && <span style={{fontSize:9,color:'var(--md-outline)',marginLeft:4}}>OCR…</span>}</label>
                      <input type="text" value={upiTransactionId} onChange={e => setUpiTransactionId(e.target.value)} placeholder="Auto-detected from screenshot" />
                    </div>
                    <div className="fld">
                      <label>Transaction Date/Time</label>
                      <input type="datetime-local" value={transactionDatetime} onChange={e => setTransactionDatetime(e.target.value)} />
                    </div>
                  </div>
                  {ocrFromName && (
                    <div className="detail-field-row">
                      <div className="fld">
                        <label>Detected From Name</label>
                        <input type="text" value={ocrFromName} onChange={e => setOcrFromName(e.target.value)} placeholder="Auto-detected from screenshot" style={{color:'var(--md-outline)',fontStyle:'italic'}} readOnly />
                      </div>
                    </div>
                  )}
                  <div className="detail-field-row">
                    <div className="fld">
                      <label>Address</label>
                      <input type="text" value={leadAddress} onChange={e => setLeadAddress(e.target.value)} placeholder="Donor address" />
                    </div>
                  </div>
                  <div className="detail-field-row">
                    <div className="fld">
                      <label>PAN</label>
                      <input type="text" value={leadPan} onChange={e => {
                        const v = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
                        setLeadPan(v);
                        if (v.length === 0) {
                          setPanError('');
                        } else if (!PAN_REGEX.test(v) && v.length === 10) {
                          setPanError('Invalid PAN — use format: ABCDE1234F');
                        } else if (v.length > 0 && v.length < 10) {
                          setPanError('PAN must be 10 characters');
                        } else {
                          setPanError('');
                        }
                      }} placeholder="e.g. ABCDE1234F" maxLength={10} style={{ borderColor: panError ? '#dc2626' : undefined }} />
                      {leadPan.length > 0 && panError && <span style={{ fontSize: 9, color: '#dc2626', marginTop: 1, display: 'block' }}>{panError}</span>}
                    </div>
                    <div className="fld">
                      <label>DOB</label>
                      <input type="date" value={leadDob} onChange={e => setLeadDob(e.target.value)} />
                    </div>
                  </div>
                </div>
              )}

              {/* Remark — available for every disposition so the FRO can always note why */}
              {selected && (
                <>
                  <div className="detail-field-row">
                    <div className="fld">
                      <button onClick={() => setShowRemark(!showRemark)}
                        style={{ padding:'6px 14px', border:`1px solid ${showRemark ? 'var(--sage)' : (remarkError ? '#dc2626' : 'var(--line)')}`, borderRadius:6, background: showRemark ? 'var(--sage)' : '#fff', color: showRemark ? '#fff' : 'var(--ink)', fontSize:10, fontWeight:700, fontFamily:'inherit', cursor:'pointer', transition:'all .12s' }}>
                        {showRemark ? 'Hide Remark' : 'Add Remark'}
                      </button>
                    </div>
                  </div>
                  {showRemark && (
                    <div className="detail-field-row">
                      <div className="fld">
                        <textarea value={leadRemark} onChange={e => { setLeadRemark(e.target.value); setRemarkError(false); }} rows={2} placeholder="Enter remark..." style={{ width:'100%', padding:'6px 8px', border:`1px solid ${remarkError ? '#dc2626' : 'var(--line)'}`, borderRadius:6, fontSize:11, fontFamily:'inherit', resize:'vertical', boxSizing:'border-box' }} />
                      </div>
                    </div>
                  )}
                </>
              )}

              {/* Notes */}
              <div className="detail-notes">
                <label style={{ display: 'block', fontSize: 9, fontWeight: 600, color: 'var(--ink-soft)', textTransform: 'uppercase', letterSpacing: .5, marginBottom: 3 }}>Notes</label>
                <textarea value={notes} onChange={e => { setNotes(e.target.value); setRemarkError(false); }} rows={2} placeholder="Add notes here..." style={{ border: remarkError ? '1px solid #dc2626' : undefined }} />
              </div>

              {/* Remarks & Notes — every saved remark/note for this donor, all time */}
              {remarks.length > 0 && (
                <div style={{ borderTop: '1px solid var(--line)', paddingTop: 10, paddingBottom: 4 }}>
                  <label style={{ display: 'block', fontSize: 9, fontWeight: 600, color: 'var(--ink-soft)', textTransform: 'uppercase', letterSpacing: .5, marginBottom: 6 }}>Remarks &amp; Notes ({remarks.length})</label>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {remarks.slice(0, showAllRemarks ? remarks.length : 5).map(r => (
                      <div key={r.id} style={{ background: '#f8fafc', border: '1px solid var(--line)', borderRadius: 6, padding: '6px 8px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 6 }}>
                          <span style={{ fontSize: 9, fontWeight: 700, color: 'var(--ink)', textTransform: 'uppercase', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{dispLabel(r)}</span>
                          <span style={{ fontSize: 9, color: 'var(--ink-soft)', flexShrink: 0 }}>{formatTime(logDate(r))}</span>
                        </div>
                        <div style={{ fontSize: 11, color: 'var(--ink)', marginTop: 2, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{r.remark || r.notes}</div>
                      </div>
                    ))}
                    {remarks.length > 5 && (
                      <div style={{ textAlign: 'center', padding: '4px 0 0' }}>
                        <button onClick={() => setShowAllRemarks(s => !s)}
                          style={{ padding: '4px 12px', border: '1px solid var(--line)', borderRadius: 6, background: 'transparent', fontSize: 10, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer', color: 'var(--sage)' }}>
                          {showAllRemarks ? 'Show Less' : `Show All ${remarks.length} Remarks`}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
            </>
            )}
          </div>
        </div>

        {/* RIGHT PANEL — Timeline (20%) */}
        <div className="detail-right" style={{ padding: '12px 12px 12px 0' }}>
          {/* Timeline card */}
          <div className="detail-card" style={{ flex: 1, minHeight: 0 }}>
            <div className="detail-card-head">
              <span>CRM Timeline</span>
              {totalCollected > 0 && <span style={{ color: 'var(--sage)', fontSize: 10 }}>₹{totalCollected.toLocaleString('en-IN')}</span>}
            </div>
            <div className="detail-card-scroll">
              {detailLoading ? (
                <div className="empty-timeline">Loading...</div>
              ) : logs.length === 0 ? (
                <div className="empty-timeline">No activity yet.</div>
              ) : (
                <div className="detail-timeline-list">
                  {logs.slice(0, showAllLogs ? logs.length : 12).map(log => {
                    const isDisp = log.action === 'disposition';
                    const cat = log.disposition_category;
                    const icon = timelineIcon(log);
                    const connected = isDisp && cat === 'connected';
                    const lbl = isDisp ? (findDisp(log.disposition_detail)?.label || String(log.disposition_detail || '').replace(/_/g, ' ') || '') : (log.action === 'month_reset' ? 'Monthly reset' : log.action.replace(/_/g, ' '));
                    const bg = isDisp ? (connected ? '#f0fdf4' : '#fef2f2') : 'var(--bg)';
                    return (
                      <div key={log.id} className="detail-timeline-item" style={{ background: bg }}>
                        <span className="material-symbols-outlined" style={{ fontSize: 12, color: connected ? 'var(--sage)' : 'var(--md-error, #dc2626)', flexShrink: 0, marginTop: 1 }}>{icon}</span>
                        <div className="tl-info">
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                            <span className="tl-lbl">{lbl}</span>
                            <span className="tl-time">{formatTime(logDate(log))}</span>
                          </div>
                          {(log.remark || log.notes) && <div className="tl-note">{log.remark || log.notes}</div>}
                          {log.amount_collected != null && <div className="tl-note" style={{ color: 'var(--sage)', fontWeight: 600 }}>₹{Number(log.amount_collected).toLocaleString('en-IN')}</div>}
                          {isCollectionLog(log) && log.fro_worker_name && (
                            <div className="tl-note" style={{ color: 'var(--ink-soft)', fontSize: 9 }}>Collected by {log.fro_worker_name}</div>
                          )}
                          {log.disposition_detail === 'lead_done' && (
                            <span style={{ fontSize: 8, fontWeight: 700, background: 'var(--md-tertiary-fixed, #e0e7ff)', padding: '1px 4px', borderRadius: 2, textTransform: 'uppercase', display: 'inline-block', marginTop: 1 }}>
                              {log.accounts_status === 'verified' ? 'Verified' : log.accounts_status === 'rejected' ? 'Rejected' : 'Pending'}
                            </span>
                          )}
                          {log.disposition_detail === 'done' && (
                            <span style={{ fontSize: 8, fontWeight: 700, background: '#f0fdf4', color: 'var(--sage)', padding: '1px 4px', borderRadius: 2, textTransform: 'uppercase', display: 'inline-block', marginTop: 1 }}>Collected</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                  {logs.length > 12 && (
                    <div style={{ textAlign: 'center', padding: '8px 0' }}>
                      <button onClick={() => setShowAllLogs(s => !s)}
                        style={{ padding: '5px 14px', border: '1px solid var(--line)', borderRadius: 6, background: 'transparent', fontSize: 10, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer', color: 'var(--sage)' }}>
                        {showAllLogs ? `Show Less` : `View All ${logs.length} Logs`}
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>

    <div className="fro-action-bar">
      <button className="btn-prev" disabled={saving} onClick={() => {
        const hadUnsaved = !!selected;
        endDonorView(isOnCall && activeCall?.donorId === donor?.id);
        resetFormState();
        setResumeTo(null);
        setReturnToDonor(null);
        setExternalDonor(null);
        setShowConfirmPrev(false);
        setActiveDonor(null);
        if (hadUnsaved) setMessage({ type: 'info', text: 'Disposition not saved — select again and log it.' });
      }}>
        <span className="material-symbols-outlined" style={{ fontSize: 14 }}>format_list_bulleted</span> Back to List
      </button>

      <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center', paddingRight: 4 }}>
        {isOnCall && activeCall?.donorId === donor?.id ? (
          <button onClick={endCall} disabled={saving} className="fro-btn-end-call" style={saving ? { opacity: .5, cursor: 'not-allowed' } : undefined}>
            <span className="fro-pulse-dot" />
            End Call
          </button>
        ) : (
          <span className="fro-btn-call" style={{ opacity: .55, cursor: 'default', pointerEvents: 'none' }}>
            <span className="material-symbols-outlined" style={{ fontSize: 14 }}>call</span>
            Call Now
          </span>
        )}

        <button className="btn-next"
          disabled={saving || !selected}
          onClick={() => { endDonorView(isOnCall); handleSave() }}>
          {saving ? 'Saving...' : selected ? (
            <><span className="material-symbols-outlined" style={{ fontSize: 13 }}>check</span> Log {findDisp(selected)?.label || selected}</>
          ) : (
            <><span className="material-symbols-outlined" style={{ fontSize: 13 }}>check</span> Save & Back to List</>
          )}
        </button>
      </div>
    </div>

    {/* Donation Modal */}
    {showDonationModal && (
      <div style={{ position: 'fixed', inset: 0, zIndex: 2000, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,.4)' }} onClick={() => setShowDonationModal(false)}>
        <div style={{ background: '#fff', borderRadius: 12, width: isMobile ? 'calc(100vw - 32px)' : 520, maxHeight: '80vh', display: 'flex', flexDirection: 'column', boxShadow: '0 8px 32px rgba(0,0,0,.15)' }} onClick={e => e.stopPropagation()}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 16px', borderBottom: '1px solid var(--line)' }}>
            <span style={{ fontSize: 13, fontWeight: 700 }}>Donations — {donor.donor_name}</span>
            <span className="material-symbols-outlined" style={{ fontSize: 18, cursor: 'pointer', color: 'var(--ink-soft)' }} onClick={() => setShowDonationModal(false)}>close</span>
          </div>
          <div style={{ padding: '10px 16px', borderBottom: '1px solid var(--line)', display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
            <span style={{ fontSize: 10, fontWeight: 600, color: 'var(--ink-soft)', whiteSpace: 'nowrap' }}>Show:</span>
            {['all', 'monthly', 'yearly'].map(f => (
              <button key={f} onClick={() => handleDonationFilterChange(f)}
                style={{ padding: '4px 10px', border: `1px solid ${donationFilter === f ? 'var(--sage)' : 'var(--line)'}`, borderRadius: 6, background: donationFilter === f ? 'var(--sage)' : '#fff', color: donationFilter === f ? '#fff' : 'var(--ink)', fontSize: 10, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer', transition: 'all .12s' }}>
                {f === 'all' ? 'All' : f === 'monthly' ? 'Monthly' : 'Yearly'}
              </button>
            ))}
            <select value={donationFilter.startsWith('year_') ? donationFilter : ''} onChange={e => handleDonationFilterChange(e.target.value)}
              style={{ padding: '4px 8px', border: `1px solid ${donationFilter.startsWith('year_') ? 'var(--sage)' : 'var(--line)'}`, borderRadius: 6, background: '#fff', fontSize: 10, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>
              <option value="">Year…</option>
              {allYears.map(y => <option key={y} value={`year_${y}`}>{y}</option>)}
            </select>
          </div>
          <div style={{ flex: 1, overflowY: 'auto', padding: 12 }}>
            {!donationLoading && (
              <div style={{ padding: '0 0 8px', fontSize: 10, fontWeight: 600, color: 'var(--ink-soft)' }}>
                {visibleDonations.length} {visibleDonations.length === 1 ? 'receipt' : 'receipts'}
              </div>
            )}
            {donationLoading ? (
              <div style={{ textAlign: 'center', padding: 20, fontSize: 11, color: 'var(--ink-soft)' }}>Loading...</div>
            ) : visibleDonations.length === 0 ? (
              <div style={{ textAlign: 'center', padding: 20, fontSize: 11, color: 'var(--ink-soft)' }}>No donations for this period.</div>
            ) : (
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid var(--line)' }}>
                    <th style={{ textAlign: 'left', padding: '5px 6px', fontSize: 9, fontWeight: 600, textTransform: 'uppercase', color: 'var(--ink-soft)' }}>Date</th>
                    <th style={{ textAlign: 'left', padding: '5px 6px', fontSize: 9, fontWeight: 600, textTransform: 'uppercase', color: 'var(--ink-soft)' }}>Amount</th>
                    <th style={{ textAlign: 'left', padding: '5px 6px', fontSize: 9, fontWeight: 600, textTransform: 'uppercase', color: 'var(--ink-soft)' }}>Mode</th>
                    <th style={{ textAlign: 'left', padding: '5px 6px', fontSize: 9, fontWeight: 600, textTransform: 'uppercase', color: 'var(--ink-soft)' }}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {visibleDonations.map((d, i) => (
                    <tr key={i} style={{ borderBottom: '1px solid var(--line)' }}>
                      <td style={{ padding: '5px 6px' }}>{d.date ? new Date(d.date).toLocaleDateString('en-GB') : '—'}</td>
                      <td style={{ padding: '5px 6px', fontWeight: 600 }}>₹{Number(d.amount || 0).toLocaleString('en-IN')}</td>
                      <td style={{ padding: '5px 6px' }}>{d.mode || '—'}</td>
                      <td style={{ padding: '5px 6px' }}><span className={`bento-pill ${d.status === 'verified' ? 'bento-pill-green' : d.status === 'rejected' ? 'bento-pill-red' : 'bento-pill-yellow'}`}>{d.status || '—'}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
          <div style={{ padding: '10px 16px', borderTop: '1px solid var(--line)', textAlign: 'right', fontSize: 10, color: 'var(--ink-soft)' }}>
            Total: ₹{Math.round(visibleDonations.reduce((s, d) => s + Number(d.amount || 0), 0)).toLocaleString('en-IN')}
          </div>
        </div>
      </div>
    )}
    {showConfirmPrev && (
      <div className="modal-overlay" onClick={() => setShowConfirmPrev(false)}>
        <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: 380 }}>
          <div className="modal-body" style={{ textAlign: 'center', padding: '24px 22px' }}>
            <span className="material-symbols-outlined" style={{ fontSize: 36, color: '#f59e0b' }}>warning</span>
            <h3 style={{ margin: '10px 0 4px', fontSize: 15, fontWeight: 700 }}>Discard Disposition?</h3>
            <p style={{ margin: 0, fontSize: 13, color: 'var(--ink-soft)' }}>You have an unsaved disposition selection. Changing leads will discard it.</p>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginTop: 18 }}>
              <button className="btn" onClick={() => setShowConfirmPrev(false)}
                style={{ padding: '8px 20px', borderRadius: 6, fontSize: 12, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>
                Cancel
              </button>
              <button className="btn" onClick={() => { setShowConfirmPrev(false); prevActionRef.current?.(); }}
                style={{ padding: '8px 20px', borderRadius: 6, fontSize: 12, fontWeight: 700, fontFamily: 'inherit', cursor: 'pointer', background: '#dc2626', color: '#fff', border: 'none' }}>
                Discard
              </button>
            </div>
          </div>
        </div>
      </div>
    )}
    </div>
  );
  if (embedded && portalEl) return createPortal(detailTree, portalEl);
  return detailTree;
}