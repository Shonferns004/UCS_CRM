import { useState, useEffect, useRef, useCallback } from 'react';
import { addReminder, updateReminder, fetchReminderHistory, importReminders } from './api';
import { toast } from './Toast';
import {
  CATEGORIES,
  FREQUENCY_OPTIONS,
  PRIORITIES,
  REMIND_BEFORE_OPTIONS,
  FREQUENCY_FORM_OPTIONS,
  REMIND_DAYS_BEFORE_OPTIONS,
  fieldsToFreqOption,
  freqOptionToFields,
  computeNextDue,
  computeRenewal,
  todayStr,
  formatDateTime,
  formatDate,
} from './helpers';
import { computeEffectiveDueDate, playAlarmSound, dismissAlarmKey } from './notifications';
import * as XLSX from 'xlsx';

/* ------------------------------------------------------------------ */
/*  FIELD LABEL MAP (shared by HistoryModal)                          */
/* ------------------------------------------------------------------ */
const FIELD_LABELS = {
  title: 'Reminder Name',
  category: 'Category',
  owner: 'Owner',
  description: 'Description',
  due_date: 'Due Date',
  renewal_date: 'Renewal Date',
  frequency_type: 'Frequency Type',
  frequency_interval: 'Frequency Interval',
  day_of_month: 'Day of Month',
  month_of_year: 'Month of Year',
  priority: 'Priority',
  alarm_enabled: 'Alarm Enabled',
  reminder_enabled: 'Reminder Enabled',
  reminder_time: 'Reminder Time',
  reminder_minutes_before: 'Reminder Minutes Before',
  notification_enabled: 'Notification Enabled',
  notes: 'Notes',
};

const fieldLabel = (key) => FIELD_LABELS[key] || key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());

const STATUS_OPTIONS = ['Upcoming', 'Completed', 'Snoozed'];

/* ================================================================== */
/*  1. ReminderFormModal                                               */
/* ================================================================== */
export function ReminderFormModal({ open, reminder, onClose, onSaved, onDelete }) {
  const isEdit = reminder != null;
  const originalRef = useRef(null);

  const emptyForm = {
    title: '',
    category: '',
    owner: '',
    description: '',
    due_date: '',
    renewal_date: '',
    frequency_type: '',
    frequency_interval: '',
    day_of_month: '',
    month_of_year: '',
    frequency: 'ONE_TIME',
    remind_days_before: '0',
    last_paid_date: '',
    priority: 'Medium',
    status: 'Upcoming',
    alarm_enabled: false,
    reminder_enabled: false,
    reminder_time: '',
    reminder_minutes_before: '',
    notification_enabled: false,
    notes: '',
    amount: '',
  };

  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      if (isEdit) {
        const mapped = {};
        Object.keys(emptyForm).forEach((k) => {
          if (k === 'frequency' || k === 'last_paid_date') return;
          mapped[k] = reminder[k] != null ? reminder[k] : emptyForm[k];
        });
        mapped.frequency = fieldsToFreqOption(reminder.frequency_type, reminder.frequency_interval);
        mapped.last_paid_date = '';
        if (reminder.paid_at) mapped.last_paid_date = String(reminder.paid_at).slice(0, 10);
        mapped.remind_days_before = reminder.remind_days_before == null ? '0' : String(reminder.remind_days_before);
        setForm(mapped);
        originalRef.current = { ...mapped };
      } else {
        setForm({ ...emptyForm, due_date: todayStr() });
        originalRef.current = null;
      }
    }
  }, [open, isEdit, reminder?.id]);

  const set = useCallback((key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  }, []);

  const refreshDueAndRenewal = useCallback(({ frequency, lastPaid, dueDate, remindDays }) => {
    setForm((prev) => {
      const freqOpt = FREQUENCY_FORM_OPTIONS.find(o => o.value === frequency);
      const type = freqOpt ? freqOpt.type : 'ONE_TIME';
      let nextDue = prev.due_date;
      if (type !== 'ONE_TIME' && lastPaid) {
        const computed = computeNextDue(lastPaid, type, freqOpt.interval, todayStr());
        if (computed) nextDue = computed;
      }
      return {
        ...prev,
        due_date: nextDue,
        renewal_date: computeRenewal(nextDue, remindDays === '' ? '' : remindDays),
      };
    });
  }, []);

  if (!open) return null;

  const handleChange = (key) => (e) => {
    const val = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    set(key, val);
  };

  const handleFrequencyChange = (e) => {
    const val = e.target.value;
    set('frequency', val);
    refreshDueAndRenewal({
      frequency: val,
      lastPaid: form.last_paid_date,
      dueDate: form.due_date,
      remindDays: form.remind_days_before,
    });
  };

  const handleLastPaidChange = (e) => {
    const val = e.target.value;
    set('last_paid_date', val);
    refreshDueAndRenewal({
      frequency: form.frequency,
      lastPaid: val,
      dueDate: form.due_date,
      remindDays: form.remind_days_before,
    });
  };

  const handleDueDateChange = (e) => {
    const val = e.target.value;
    set('due_date', val);
    set('renewal_date', computeRenewal(val, form.remind_days_before));
  };

  const handleRemindDaysChange = (e) => {
    const val = e.target.value;
    set('remind_days_before', val);
    set('renewal_date', computeRenewal(form.due_date, val));
  };

  const handleSave = async () => {
    if (!form.title.trim()) {
      toast('Title is required', 'error');
      return;
    }

    const payload = {};
    const norm = (v) => (v === undefined || v === null) ? '' : String(v);
    Object.keys(form).forEach((k) => {
      if (isEdit && originalRef.current) {
        const orig = norm(originalRef.current[k]);
        const curr = norm(form[k]);
        if (orig !== curr) {
          payload[k] = form[k];
        }
      } else {
        if (k === 'title') {
          payload[k] = form[k];
          return;
        }
        if (form[k] !== '' && form[k] !== false) {
          payload[k] = form[k];
        }
      }
    });

    if (!payload.title) payload.title = form.title;

    // Strip UI-only keys (not real DB columns).
    delete payload.frequency;
    delete payload.last_paid_date;

    // Structured frequency from the friendly dropdown.
    const freqOpt = freqOptionToFields(form.frequency || (isEdit ? fieldsToFreqOption(form.frequency_type, form.frequency_interval) : 'ONE_TIME'));
    payload.frequency_type = freqOpt.frequency_type;
    payload.frequency_interval = freqOpt.frequency_interval;
    if (!payload.frequency_type || payload.frequency_type === 'ONE_TIME') payload.frequency_interval = null;

    // Remind-N-days-before (renewal/alert lead time).
    const remindDays = form.remind_days_before === '' || form.remind_days_before == null ? null : Number(form.remind_days_before);
    payload.remind_days_before = remindDays;

    // Last paid date -> paid_at (start of day, local time). Only overwrite
    // on edit if the user actually changed the date (preserves real timestamp).
    const origLastPaid = originalRef.current?.last_paid_date || '';
    if (!isEdit || form.last_paid_date !== origLastPaid) {
      if (form.last_paid_date) {
        payload.paid_at = `${form.last_paid_date}T00:00:00`;
      } else {
        payload.paid_at = null;
      }
    }

    // If frequency set + last paid present but due not computed, compute next due.
    if (!form.due_date && form.last_paid_date && freqOpt.frequency_type !== 'ONE_TIME') {
      const nextDue = computeNextDue(form.last_paid_date, freqOpt.frequency_type, freqOpt.frequency_interval, todayStr());
      payload.due_date = nextDue;
      payload.renewal_date = computeRenewal(nextDue, remindDays);
    }

    if (payload.amount != null && payload.amount !== '') {
      payload.amount = Number(payload.amount);
    } else if (payload.amount === '' || payload.amount === null) {
      payload.amount = null;
    }

    if (isEdit && Object.keys(payload).length === 0) {
      toast('No changes to save', 'info');
      return;
    }

    setSaving(true);
    try {
      if (isEdit) {
        await updateReminder(reminder.id, payload);
      } else {
        await addReminder(payload);
      }
      toast('Reminder saved successfully', 'success');
      onSaved?.();
      onClose();
    } catch (err) {
      toast(err.message || 'Failed to save reminder', 'error');
    } finally {
      setSaving(false);
    }
  };

  const showCustomFreq = form.frequency_type === 'CUSTOM';

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <h3>{isEdit ? 'Edit Reminder' : 'Add Reminder'}</h3>
          <button className="rem-btn" onClick={onClose}>
            &times;
          </button>
        </div>

        <div className="modal-body">
          <div className="form-grid">
            {/* Title */}
            <div className="form-row">
              <label>
                Title <span style={{ color: 'var(--danger, #e74c3c)' }}>*</span>
              </label>
              <input
                className="rem-input"
                value={form.title}
                onChange={handleChange('title')}
                placeholder="Reminder title"
              />
            </div>

            {/* Category */}
            <div className="form-row">
              <label>Category</label>
              <input
                className="rem-input"
                value={form.category}
                onChange={handleChange('category')}
                placeholder="Type or select category"
                list="category-list"
              />
              <datalist id="category-list">
                {CATEGORIES.map((c) => (
                  <option key={c.key} value={c.label}>
                    {c.label}
                  </option>
                ))}
              </datalist>
            </div>

            {/* Owner */}
            <div className="form-row">
              <label>Owner</label>
              <input
                className="rem-input"
                value={form.owner}
                onChange={handleChange('owner')}
                placeholder="Owner name"
              />
            </div>

            {/* Description */}
            <div className="form-row" style={{ gridColumn: '1 / -1' }}>
              <label>Description</label>
              <textarea
                className="rem-textarea"
                rows={2}
                value={form.description}
                onChange={handleChange('description')}
                placeholder="Description"
              />
            </div>

            {/* Frequency */}
            <div className="form-row">
              <label>Recurrence / Frequency</label>
              <select className="rem-select" value={form.frequency} onChange={handleFrequencyChange}>
                {FREQUENCY_FORM_OPTIONS.map((f) => (
                  <option key={f.value} value={f.value}>{f.label}</option>
                ))}
              </select>
            </div>

            {/* Last Paid Date */}
            <div className="form-row">
              <label>Last Paid Date</label>
              <input
                className="rem-input"
                type="date"
                value={form.last_paid_date}
                onChange={handleLastPaidChange}
              />
            </div>

            {/* Due Date */}
            <div className="form-row">
              <label>Due Date</label>
              <input
                className="rem-input"
                type="date"
                value={form.due_date}
                onChange={handleDueDateChange}
              />
            </div>

            {/* Remind before (days) */}
            <div className="form-row">
              <label>Renew Alert Before (Days)</label>
              <select className="rem-select" value={form.remind_days_before} onChange={handleRemindDaysChange}>
                {REMIND_DAYS_BEFORE_OPTIONS.map((o) => (
                  <option key={o.value} value={o.value}>{o.label}</option>
                ))}
              </select>
            </div>

            {/* Renewal Date */}
            <div className="form-row">
              <label>Renewal Date</label>
              <input
                className="rem-input"
                type="date"
                value={form.renewal_date}
                onChange={handleChange('renewal_date')}
              />
            </div>

            {/* Status */}
            <div className="form-row">
              <label>Status</label>
              <select
                className="rem-select"
                value={form.status}
                onChange={handleChange('status')}
              >
                {STATUS_OPTIONS.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            {/* Amount */}
            <div className="form-row">
              <label>Amount (₹)</label>
              <input
                className="rem-input"
                type="number"
                value={form.amount}
                onChange={handleChange('amount')}
                placeholder="e.g. 4144"
              />
            </div>
          </div>
        </div>

        <div className="modal-foot">
          <button className="rem-btn" onClick={onClose} disabled={saving}>
            Cancel
          </button>
          <button className="rem-btn primary" onClick={handleSave} disabled={saving}>
            {saving ? 'Saving...' : isEdit ? 'Update' : 'Save'}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  2. HistoryModal                                                    */
/* ================================================================== */
export function HistoryModal({ reminderId, reminder, open, onClose }) {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open && reminderId) {
      setLoading(true);
      fetchReminderHistory(reminderId)
        .then((data) => setHistory(Array.isArray(data) ? data : data.results || []))
        .catch(() => setHistory([]))
        .finally(() => setLoading(false));
    }
    if (!open) {
      setHistory([]);
    }
  }, [open, reminderId]);

  if (!open) return null;

  const formatVal = (v) => {
    if (v === null || v === undefined || v === '') return '(empty)';
    if (typeof v === 'boolean') return v ? 'Yes' : 'No';
    return String(v);
  };

  const actionIcon = (action) => {
    switch (action) {
      case 'updated': return '✏';
      case 'completed': return '✓';
      case 'completed_and_advanced': return '⟳';
      case 'snoozed': return '🌙';
      default: return '•';
    }
  };

  const actionColor = (action) => {
    switch (action) {
      case 'updated': return { bg: '#dbeafe', fg: '#2563eb' };
      case 'completed': return { bg: '#dcfce7', fg: '#16a34a' };
      case 'completed_and_advanced': return { bg: '#dcfce7', fg: '#16a34a' };
      case 'snoozed': return { bg: '#fef3c7', fg: '#d97706' };
      default: return { bg: '#f1f5f9', fg: '#64748b' };
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" style={{ maxWidth: 520 }} onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <h3>Change History</h3>
          <button className="modal-x" onClick={onClose}>&times;</button>
        </div>
        <div className="modal-body" style={{ maxHeight: 520, overflowY: 'auto', padding: '12px 20px' }}>
          {reminder && (reminder.notes || reminder.amount != null) && (
            <div style={{
              marginBottom: 16, padding: '10px 14px', borderRadius: 8,
              background: 'linear-gradient(135deg, #f0fdf4, #dcfce7)',
              border: '1px solid #bbf7d0',
            }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: '#16a34a', textTransform: 'uppercase', letterSpacing: '.05em', marginBottom: 6 }}>
                Payment Info
              </div>
              {reminder.amount != null && (
                <div style={{ fontSize: 13, color: '#15803d', fontWeight: 500 }}>
                  {reminder.paid_at
                    ? `${(() => { const d = new Date(reminder.paid_at); return `${d.getDate()}.${d.getMonth() + 1}.${d.getFullYear()}` })()} | Rs. ${Number(reminder.amount).toLocaleString()}`
                    : `Rs. ${Number(reminder.amount).toLocaleString()}`
                  }
                </div>
              )}
              {reminder.notes && (
                <div style={{ fontSize: 13, color: '#15803d', fontWeight: 500, marginTop: reminder.amount != null ? 4 : 0 }}>
                  {reminder.notes}
                </div>
              )}
            </div>
          )}
          {loading ? (
            <div style={{ textAlign: 'center', padding: 40, color: '#94a3b8', fontSize: 13 }}>Loading...</div>
          ) : history.length === 0 ? (
            <div style={{ textAlign: 'center', padding: 40, color: '#94a3b8', fontSize: 13 }}>No history yet</div>
          ) : (
            <div style={{ position: 'relative', paddingLeft: 24 }}>
              <div style={{ position: 'absolute', left: 9, top: 8, bottom: 8, width: 2, background: '#e2e8f0', borderRadius: 1 }} />
              {history.map((entry, idx) => {
                const ac = actionColor(entry.action);
                return (
                  <div key={entry.id || idx} style={{ position: 'relative', marginBottom: idx < history.length - 1 ? 20 : 0 }}>
                    <div style={{
                      position: 'absolute', left: -24, top: 2, width: 20, height: 20, borderRadius: '50%',
                      background: ac.bg, border: `2px solid ${ac.fg}`, display: 'flex', alignItems: 'center',
                      justifyContent: 'center', fontSize: 10, color: ac.fg, zIndex: 1,
                    }}>
                      {actionIcon(entry.action)}
                    </div>
                    <div style={{ fontSize: 11, color: '#94a3b8', marginBottom: 4 }}>
                      {formatDateTime(entry.changed_at || entry.timestamp)}
                      <span style={{ margin: '0 4px', color: '#cbd5e1' }}>·</span>
                      <span style={{ color: '#64748b' }}>{entry.changed_by || 'System'}</span>
                    </div>
                    <div style={{
                      fontSize: 12, fontWeight: 600, color: ac.fg, display: 'inline-flex',
                      alignItems: 'center', gap: 4, padding: '2px 8px', borderRadius: 4,
                      background: ac.bg, marginBottom: 6,
                    }}>
                      {entry.action === 'updated' && 'Updated'}
                      {entry.action === 'completed' && 'Completed'}
                      {entry.action === 'snoozed' && 'Snoozed'}
                      {entry.action === 'completed_and_advanced' && 'Completed & Advanced'}
                      {!['updated', 'completed', 'snoozed', 'completed_and_advanced'].includes(entry.action) && entry.action}
                    </div>
                    {entry.changed_cols && Object.entries(entry.changed_cols).map(([key, val]) => {
                      let oldVal, newVal;
                      if (val && typeof val === 'object' && 'old' in val && 'new' in val) {
                        oldVal = val.old; newVal = val.new;
                      } else if (Array.isArray(val)) {
                        oldVal = val[0]; newVal = val[1];
                      } else {
                        oldVal = null; newVal = val;
                      }
                      if (oldVal === newVal) return null;
                      return (
                        <div key={key} style={{
                          fontSize: 12, color: '#475569', marginBottom: 3,
                          display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap',
                        }}>
                          <span style={{ fontWeight: 600, color: '#334155' }}>{fieldLabel(key)}</span>
                          <span style={{ color: '#ef4444', textDecoration: 'line-through', fontSize: 11 }}>{formatVal(oldVal)}</span>
                          <span style={{ color: '#94a3b8' }}>→</span>
                          <span style={{ color: '#16a34a', fontWeight: 500 }}>{formatVal(newVal)}</span>
                        </div>
                      );
                    })}
                  {entry.action === 'completed' || entry.action === 'completed_and_advanced' ? (
                      (entry.after_data?.transaction_id || entry.after_data?.paid_by) && (
                        <div key="payment-details" style={{
                          fontSize: 12, color: '#166534', marginTop: 4, display: 'flex',
                          alignItems: 'center', gap: 6, flexWrap: 'wrap',
                        }}>
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
                          {entry.after_data.transaction_id && (
                            <span>Txn <strong>{entry.after_data.transaction_id}</strong></span>
                          )}
                          {entry.after_data.paid_by && (
                            <span>· Paid by <strong>{entry.after_data.paid_by}</strong></span>
                          )}
                        </div>
                      )
                    ) : null}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  3. DeleteConfirmModal                                              */
/* ================================================================== */
export function DeleteConfirmModal({ reminder, deleting, onClose, onConfirm }) {
  if (!reminder) return null;

  return (
    <div className="dc-overlay" onClick={onClose}>
      <div className="dc-modal" onClick={(e) => e.stopPropagation()}>
        <div className="dc-icon">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#e74c3c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="3 6 5 6 21 6" />
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
            <line x1="10" y1="11" x2="10" y2="17" />
            <line x1="14" y1="11" x2="14" y2="17" />
          </svg>
        </div>
        <div className="dc-title">Delete Reminder</div>
        <div className="dc-desc">
          Are you sure you want to delete{' '}
          <strong>{reminder.title}</strong>? This action cannot be undone.
        </div>
        <div className="dc-foot">
          <button className="dc-btn cancel" onClick={onClose} disabled={deleting}>
            Cancel
          </button>
          <button className="dc-btn delete" onClick={() => onConfirm(reminder)} disabled={deleting}>
            {deleting ? 'Deleting...' : 'Delete'}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  4. ImportModal                                                     */
/* ================================================================== */
const HEADER_MAP = {
  'reminder name': 'title',
  'title': 'title',
  'name': 'title',
  'category': 'category',
  'owner': 'owner',
  'description': 'description',
  'desc': 'description',
  'due date': 'due_date',
  'duedate': 'due_date',
  'due_date': 'due_date',
  'renewal date': 'renewal_date',
  'renewaldate': 'renewal_date',
  'renewal_date': 'renewal_date',
  'frequency type': 'frequency_type',
  'frequencytype': 'frequency_type',
  'frequency_type': 'frequency_type',
  'frequency interval': 'frequency_interval',
  'frequencyinterval': 'frequency_interval',
  'frequency_interval': 'frequency_interval',
  'priority': 'priority',
  'alarm enabled': 'alarm_enabled',
  'alarmenabled': 'alarm_enabled',
  'alarm_enabled': 'alarm_enabled',
  'reminder enabled': 'reminder_enabled',
  'reminderenabled': 'reminder_enabled',
  'reminder_enabled': 'reminder_enabled',
  'reminder time': 'reminder_time',
  'remindertime': 'reminder_time',
  'reminder_time': 'reminder_time',
  'reminder minutes before': 'reminder_minutes_before',
  'reminderminutesbefore': 'reminder_minutes_before',
  'reminder_minutes_before': 'reminder_minutes_before',
  'notification enabled': 'notification_enabled',
  'notificationenabled': 'notification_enabled',
  'notification_enabled': 'notification_enabled',
  'notes': 'notes',
};

function mapHeaders(rawHeaders) {
  return rawHeaders.map((h) => {
    const key = String(h).trim().toLowerCase().replace(/\s+/g, ' ');
    return HEADER_MAP[key] || key;
  });
}

function parseBool(val) {
  if (typeof val === 'boolean') return val;
  if (typeof val === 'number') return val !== 0;
  const s = String(val).trim().toLowerCase();
  return ['true', '1', 'yes', 'y'].includes(s);
}

export function ImportModal({ open, onClose, onDone }) {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState([]);
  const [headers, setHeaders] = useState([]);
  const [validCount, setValidCount] = useState(0);
  const [invalidCount, setInvalidCount] = useState(0);
  const [importing, setImporting] = useState(false);
  const [done, setDone] = useState(false);
  const fileRef = useRef(null);

  useEffect(() => {
    if (!open) {
      setFile(null);
      setPreview([]);
      setHeaders([]);
      setValidCount(0);
      setInvalidCount(0);
      setImporting(false);
      setDone(false);
    }
  }, [open]);

  if (!open) return null;

  const handleFile = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const wb = XLSX.read(evt.target.result, { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const raw = XLSX.utils.sheet_to_json(ws, { header: 1 });
        if (raw.length < 2) {
          toast('File is empty or has no data rows', 'error');
          return;
        }
        const mappedHeaders = mapHeaders(raw[0]);
        const rows = raw.slice(1).map((row) => {
          const obj = {};
          mappedHeaders.forEach((h, i) => {
            obj[h] = row[i] ?? '';
          });
          return obj;
        });

        let valid = 0;
        let invalid = 0;
        rows.forEach((r) => {
          if (r.title && String(r.title).trim()) valid++;
          else invalid++;
        });

        setHeaders(mappedHeaders);
        setPreview(rows);
        setValidCount(valid);
        setInvalidCount(invalid);
      } catch {
        toast('Failed to parse file', 'error');
      }
    };
    reader.readAsArrayBuffer(f);
  };

  const handleImport = async () => {
    const rowsToImport = preview.filter((r) => r.title && String(r.title).trim());
    if (!rowsToImport.length) {
      toast('No valid rows to import', 'error');
      return;
    }

    setImporting(true);
    try {
      const cleaned = rowsToImport.map((r) => {
        const obj = {};
        Object.entries(r).forEach(([k, v]) => {
          if (k === 'alarm_enabled' || k === 'reminder_enabled' || k === 'notification_enabled') {
            obj[k] = parseBool(v);
          } else if (v !== '' && v !== null && v !== undefined) {
            obj[k] = v;
          }
        });
        return obj;
      });
      await importReminders(cleaned);
      toast(`Imported ${cleaned.length} reminders successfully`, 'success');
      setDone(true);
      onDone?.();
    } catch (err) {
      toast(err.message || 'Import failed', 'error');
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <h3>Import Reminders</h3>
          <button className="rem-btn" onClick={onClose}>
            &times;
          </button>
        </div>
        <div className="modal-body">
          {!file ? (
            <div style={{ textAlign: 'center', padding: 32 }}>
              <input
                ref={fileRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                style={{ display: 'none' }}
                onChange={handleFile}
              />
              <button className="rem-btn primary" onClick={() => fileRef.current?.click()}>
                Choose File (Excel / CSV)
              </button>
              <p style={{ marginTop: 12, fontSize: 13, color: '#888' }}>
                Supported formats: .xlsx, .xls, .csv
              </p>
            </div>
          ) : done ? (
            <div style={{ textAlign: 'center', padding: 32, color: 'var(--success, #27ae60)' }}>
              Import completed successfully!
            </div>
          ) : (
            <>
              <p style={{ fontSize: 13, marginBottom: 8 }}>
                <strong>{file.name}</strong> — {preview.length} rows found
              </p>
              <p style={{ fontSize: 13, marginBottom: 16 }}>
                <span style={{ color: 'var(--success, #27ae60)' }}>{validCount} valid</span>
                {invalidCount > 0 && (
                  <span style={{ color: 'var(--danger, #e74c3c)', marginLeft: 12 }}>
                    {invalidCount} invalid (missing title)
                  </span>
                )}
              </p>
              <div style={{ maxHeight: 240, overflowY: 'auto', fontSize: 12 }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr>
                      {headers.map((h) => (
                        <th
                          key={h}
                          style={{
                            textAlign: 'left',
                            padding: '6px 8px',
                            borderBottom: '2px solid #ddd',
                            fontWeight: 600,
                          }}
                        >
                          {fieldLabel(h)}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {preview.slice(0, 50).map((row, idx) => {
                      const isValid = row.title && String(row.title).trim();
                      return (
                        <tr
                          key={idx}
                          style={{
                            background: isValid ? 'transparent' : 'rgba(231,76,60,0.06)',
                          }}
                        >
                          {headers.map((h) => (
                            <td
                              key={h}
                              style={{ padding: '4px 8px', borderBottom: '1px solid #eee' }}
                            >
                              {String(row[h] ?? '')}
                            </td>
                          ))}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
        <div className="modal-foot">
          <button className="rem-btn" onClick={onClose} disabled={importing}>
            {done ? 'Close' : 'Cancel'}
          </button>
          {file && !done && (
            <button
              className="rem-btn primary"
              onClick={handleImport}
              disabled={importing || validCount === 0}
            >
              {importing ? 'Importing...' : `Import ${validCount} Reminders`}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  5. NotificationPanel                                               */
/* ================================================================== */
const LEVEL_STYLES = {
  overdue: { color: '#e74c3c', bg: 'rgba(231,76,60,0.08)' },
  due_today: { color: '#f39c12', bg: 'rgba(243,156,18,0.08)' },
  due_soon: { color: '#f1c40f', bg: 'rgba(241,196,15,0.08)' },
  upcoming: { color: '#3498db', bg: 'rgba(52,152,219,0.08)' },
};

const LEVEL_LABELS = {
  overdue: 'Overdue',
  due_today: 'Due Today',
  due_soon: 'Due Soon',
  upcoming: 'Upcoming',
};

export function NotificationPanel({ notifications = [], onClose, onMarkRead, onMarkAllRead, onClickReminder, onTest }) {
  const panelRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (panelRef.current && !panelRef.current.contains(e.target)) {
        onClose?.();
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [onClose]);

  const grouped = {};
  notifications.forEach((n) => {
    const level = n.level || 'upcoming';
    if (!grouped[level]) grouped[level] = [];
    grouped[level].push(n);
  });

  const levelOrder = ['overdue', 'due_today', 'due_soon', 'upcoming'];

  return (
    <div className="notif-panel" ref={panelRef}>
      <div className="notif-header">
        <h4>Notifications</h4>
        {notifications.some((n) => !n.read) && (
          <button className="rem-btn" onClick={onMarkAllRead} style={{ fontSize: 12 }}>
            Mark All as Read
          </button>
        )}
      </div>
      <div className="notif-body" style={{ maxHeight: 400, overflowY: 'auto' }}>
        {notifications.length === 0 ? (
          <div style={{ padding: 24, textAlign: 'center', color: '#888', fontSize: 13 }}>
            No notifications
          </div>
        ) : (
          levelOrder.map((level) => {
            const items = grouped[level];
            if (!items || items.length === 0) return null;
            const style = LEVEL_STYLES[level] || LEVEL_STYLES.upcoming;
            return (
              <div key={level}>
                <div
                  style={{
                    fontSize: 11,
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    color: style.color,
                    padding: '8px 14px 4px',
                    letterSpacing: 0.5,
                  }}
                >
                  {LEVEL_LABELS[level] || level} ({items.length})
                </div>
                {items.map((n) => (
                  <div
                    key={n.id}
                    className="notif-item"
                    style={{
                      padding: '10px 14px',
                      borderBottom: '1px solid #f0f0f0',
                      cursor: 'pointer',
                      background: n.read ? 'transparent' : style.bg,
                      opacity: n.read ? 0.65 : 1,
                    }}
                    onClick={() => onClickReminder?.(n)}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 2 }}>
                          {n.title || n.message}
                        </div>
                        {n.due_date && (
                          <div style={{ fontSize: 11, color: '#888' }}>
                            Due: {formatDateTime(n.due_date)}
                          </div>
                        )}
                      </div>
                      {!n.read && (
                        <button
                          className="rem-btn"
                          onClick={(e) => {
                            e.stopPropagation();
                            onMarkRead?.(n.id);
                          }}
                          style={{ fontSize: 11, padding: '2px 8px', flexShrink: 0, marginLeft: 8 }}
                        >
                          Mark Read
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            );
          })
        )}
      </div>
      {onTest && (
        <div className="notif-test">
          <div
            style={{
              fontSize: 11,
              fontWeight: 700,
              textTransform: 'uppercase',
              color: '#888',
              padding: '8px 14px 4px',
              letterSpacing: 0.5,
            }}
          >
            Test Notifications
          </div>
          <div style={{ display: 'flex', gap: 6, padding: '4px 14px 12px' }}>
            <button className="rem-btn" onClick={() => onTest('DUE_SOON')} style={{ fontSize: 11, padding: '4px 10px' }}>
              🔔 Test Due Soon
            </button>
            <button className="rem-btn" onClick={() => onTest('DUE_TODAY')} style={{ fontSize: 11, padding: '4px 10px' }}>
              🔔 Test Due Today
            </button>
            <button className="rem-btn" onClick={() => onTest('OVERDUE')} style={{ fontSize: 11, padding: '4px 10px' }}>
              🔔 Test Overdue
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  6. AlarmToast                                                      */
/* ================================================================== */
export function AlarmToast({ reminder, alarmType, onDismiss, onComplete, onSnooze, onView }) {
  const [showSnooze, setShowSnooze] = useState(false);
  const timerRef = useRef(null);
  const soundPlayed = useRef(false);

  useEffect(() => {
    if (!reminder) return;
    setShowSnooze(false);
    if (!soundPlayed.current) {
      playAlarmSound(alarmType);
      soundPlayed.current = true;
    }
    timerRef.current = setTimeout(() => {
      onDismiss?.();
    }, 60000);
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [reminder?.id, onDismiss]);

  if (!reminder) return null;

  const effectiveDate = computeEffectiveDueDate(reminder)
  const alarmMsg =
    alarmType === 'OVERDUE' || alarmType === 'overdue'
      ? 'This reminder is overdue!'
      : alarmType === 'DUE_SOON' || alarmType === 'due_soon'
      ? 'This reminder is due soon'
      : alarmType === 'DUE_TODAY' || alarmType === 'due_today'
      ? 'This reminder is due today'
      : 'Reminder alert';

  const snoozeOptions = [
    { label: '5 min', minutes: 5 },
    { label: '15 min', minutes: 15 },
    { label: '30 min', minutes: 30 },
    { label: '60 min', minutes: 60 },
  ];

  return (
    <div className="alarm-toast">
      <div className="alarm-toast-head">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#f39c12" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
            <path d="M13.73 21a2 2 0 0 1-3.46 0" />
          </svg>
          <strong style={{ fontSize: 14 }}>{reminder.title}</strong>
        </div>
      </div>
      <div className="alarm-toast-body">
        <div style={{ fontSize: 13, marginBottom: 4 }}>{alarmMsg}</div>
        {effectiveDate ? (
          <div style={{ fontSize: 12, color: '#888' }}>Due: {formatDate(effectiveDate)}</div>
        ) : reminder.due_date ? (
          <div style={{ fontSize: 12, color: '#888' }}>Due: {formatDateTime(reminder.due_date)}</div>
        ) : null}
        {reminder.amount > 0 && (
          <div style={{ fontSize: 12, color: '#888' }}>Amount: ₹{Number(reminder.amount).toLocaleString('en-IN')}</div>
        )}
      </div>
      <div className="alarm-toast-actions">
        <button className="rem-btn" onClick={() => onView?.(reminder)}>
          View
        </button>
        <div style={{ position: 'relative', display: 'inline-block' }}>
          <button
            className="rem-btn"
            onClick={() => setShowSnooze((v) => !v)}
          >
            Snooze
          </button>
          {showSnooze && (
            <div
              style={{
                position: 'absolute',
                bottom: '100%',
                left: 0,
                background: '#fff',
                border: '1px solid #ddd',
                borderRadius: 6,
                boxShadow: '0 4px 12px rgba(0,0,0,0.12)',
                zIndex: 10,
                minWidth: 100,
              }}
            >
              {snoozeOptions.map((opt) => (
                <div
                  key={opt.minutes}
                  style={{
                    padding: '8px 14px',
                    cursor: 'pointer',
                    fontSize: 13,
                    whiteSpace: 'nowrap',
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = '#f5f5f5')}
                  onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}
                  onClick={() => {
                    setShowSnooze(false);
                    onSnooze?.(reminder, opt.minutes);
                  }}
                >
                  {opt.label}
                </div>
              ))}
            </div>
          )}
        </div>
        <button className="rem-btn primary" onClick={() => onComplete?.(reminder)}>
          Mark Complete
        </button>
        <button className="rem-btn" onClick={() => onDismiss?.()}>
          Dismiss
        </button>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  AddBillModal — clean "Add Bill" form for the dashboard            */
/* ================================================================== */
export function AddBillModal({ open, onClose, onSaved }) {
  const emptyForm = {
    title: '',
    category: '',
    owner: '',
    amount: '',
    due_date: '',
    notes: '',
  };
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) setForm(emptyForm);
  }, [open]);

  if (!open) return null;

  const handleChange = (key) => (e) => {
    setForm((prev) => ({ ...prev, [key]: e.target.value }));
  };

  const handleSave = async () => {
    if (!String(form.title).trim()) {
      toast('Bill name is required', 'error');
      return;
    }
    setSaving(true);
    try {
      const payload = { title: String(form.title).trim() };
      const catValue = String(form.category || '').trim();
      const catMatch = CATEGORIES.find((c) => c.label.toLowerCase() === catValue.toLowerCase());
      if (catMatch) payload.category = catMatch.key;
      else if (catValue) payload.category = catValue;
      if (form.owner) payload.owner = String(form.owner).trim();
      if (form.amount !== '' && form.amount != null && !isNaN(Number(form.amount))) {
        payload.amount = Number(form.amount);
      }
      if (form.due_date) payload.due_date = form.due_date;
      if (form.notes) payload.notes = String(form.notes).trim();
      await addReminder(payload);
      toast('Bill added successfully', 'success');
      onClose();
      onSaved?.();
    } catch (err) {
      toast(err.message || 'Failed to add bill', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="modal-overlay bill-overlay" onClick={onClose}>
      <div className="modal bill-modal" style={{ maxWidth: 440 }} onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <h3>Add Bill</h3>
          <button className="rem-btn" onClick={onClose}>
            &times;
          </button>
        </div>
        <div className="modal-body">
          <div className="form-grid">
            <div className="form-row" style={{ gridColumn: '1 / -1' }}>
              <label>
                Bill Name <span style={{ color: '#e74c3c' }}>*</span>
              </label>
              <input
                className="rem-input bill-title-input"
                value={form.title}
                onChange={handleChange('title')}
                placeholder="e.g. Electricity Bill, Broadband Recharge…"
                autoFocus
              />
            </div>
            <div className="form-row">
              <label>Category</label>
              <input
                className="rem-input"
                list="bill-category-options"
                value={form.category}
                onChange={handleChange('category')}
                placeholder="Select or type a category…"
              />
              <datalist id="bill-category-options">
                {CATEGORIES.map((c) => (
                  <option key={c.key} value={c.label} />
                ))}
              </datalist>
            </div>
            <div className="form-row">
              <label>Owner</label>
              <input
                className="rem-input"
                value={form.owner}
                onChange={handleChange('owner')}
                placeholder="Owner name (optional)"
              />
            </div>
            <div className="form-row">
              <label>Amount (₹)</label>
              <input
                className="rem-input"
                type="number"
                min={0}
                value={form.amount}
                onChange={handleChange('amount')}
                placeholder="e.g. 2500"
              />
            </div>
            <div className="form-row">
              <label>Due Date</label>
              <input
                className="rem-input"
                type="date"
                value={form.due_date}
                onChange={handleChange('due_date')}
              />
            </div>
            <div className="form-row" style={{ gridColumn: '1 / -1' }}>
              <label>Notes (optional)</label>
              <textarea
                className="rem-textarea"
                rows={2}
                value={form.notes}
                onChange={handleChange('notes')}
                placeholder="Any extra details"
              />
            </div>
          </div>
        </div>
        <div className="modal-foot">
          <button className="rem-btn" onClick={onClose}>
            Cancel
          </button>
          <button className="rem-btn primary" onClick={handleSave} disabled={saving}>
            {saving ? 'Saving…' : 'Add Bill'}
          </button>
        </div>
      </div>
    </div>
  );
}
