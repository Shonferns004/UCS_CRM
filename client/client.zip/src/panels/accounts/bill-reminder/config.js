export const API_BASE = import.meta.env.VITE_API_URL || 'https://api.beingsevak.org/api'

export const REM_HOME = '/accounts/bill-reminder'