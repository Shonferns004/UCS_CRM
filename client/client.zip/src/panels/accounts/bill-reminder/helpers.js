export const CATEGORIES = [
  { key: 'PROPERTY_MAINTENANCE', label: 'Property Maintenance', icon: 'home' },
  { key: 'BMC_TAX', label: 'BMC Tax', icon: 'money' },
  { key: 'RENT_TDS', label: 'Rent & TDS', icon: 'file' },
  { key: 'INSURANCE', label: 'Mediclaim, Health & Term- Insurance', icon: 'shield' },
  { key: 'MEDICAL_EXPENSES', label: 'Medical Expenses', icon: 'heart' },
  { key: 'EDUCATION', label: 'Education & School Fees', icon: 'book' },
  { key: 'VI_BILL', label: 'VI Bills', icon: 'wifi' },
  { key: 'WEBSITE_DOMAIN', label: 'Website Domain Renewal', icon: 'globe' },
  { key: 'VEHICLE_INSURANCE', label: 'Vehicle Insurance', icon: 'car' },
  { key: 'ELECTRICITY', label: 'Electricity Bills', icon: 'zap' },
  { key: 'OTHER_BILL', label: 'Other Bills', icon: 'file' },
]

export const PRIORITIES = ['Low', 'Medium', 'High', 'Critical']

export const FREQUENCY_OPTIONS = [
  { value: 'ONE_TIME', label: 'One Time' },
  { value: 'DAY', label: 'Every Day' },
  { value: 'WEEK', label: 'Every Week' },
  { value: 'MONTH', label: 'Every Month' },
  { value: 'MONTH_2', label: 'Every 2 Months' },
  { value: 'MONTH_3', label: 'Every 3 Months' },
  { value: 'MONTH_6', label: 'Every 6 Months' },
  { value: 'YEAR', label: 'Every Year' },
  { value: 'CUSTOM', label: 'Custom' },
]

export const SNOOZE_OPTIONS = [
  { value: 5, label: '5 min' },
  { value: 15, label: '15 min' },
  { value: 30, label: '30 min' },
  { value: 60, label: '1 hour' },
]

export const FREQUENCY_FORM_OPTIONS = [
  { value: 'ONE_TIME', label: 'One Time', type: 'ONE_TIME', interval: 1 },
  { value: 'MONTH', label: 'Monthly', type: 'MONTH', interval: 1 },
  { value: 'MONTH_3', label: 'Quarterly (3 Months)', type: 'MONTH', interval: 3 },
  { value: 'MONTH_6', label: 'Half-Yearly (6 Months)', type: 'MONTH', interval: 6 },
  { value: 'YEAR', label: 'Yearly', type: 'YEAR', interval: 1 },
]

export function fieldsToFreqOption(frequencyType, frequencyInterval) {
  const i = Number(frequencyInterval) || 1
  if (!frequencyType || frequencyType === 'ONE_TIME') return 'ONE_TIME'
  if (frequencyType === 'MONTH' || frequencyType === 'MONTH_3' || frequencyType === 'MONTH_6' || /^MONTH_\d+$/.test(frequencyType)) {
    if (i === 1) return 'MONTH'
    if (i === 3) return 'MONTH_3'
    if (i === 6) return 'MONTH_6'
    return 'MONTH'
  }
  if (frequencyType === 'YEAR' || frequencyType === 'YEARLY') return 'YEAR'
  return 'ONE_TIME'
}

export function freqOptionToFields(freqValue) {
  const opt = FREQUENCY_FORM_OPTIONS.find(o => o.value === freqValue) || FREQUENCY_FORM_OPTIONS[0]
  return { frequency_type: opt.type, frequency_interval: opt.interval }
}

export const REMIND_DAYS_BEFORE_OPTIONS = [
  { value: 0, label: 'At due date' },
  { value: 5, label: '5 days before' },
  { value: 10, label: '10 days before' },
  { value: 15, label: '15 days before' },
  { value: 20, label: '20 days before' },
  { value: 30, label: '30 days before' },
]

function parseISODate(dStr) {
  const s = String(dStr).slice(0, 10).split('-')
  if (s.length !== 3) return null
  const d = new Date(Number(s[0]), Number(s[1]) - 1, Number(s[2]))
  return isNaN(d.getTime()) ? null : d
}

function lastDayOfMonth(d) {
  return new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate()
}

function toISODate(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

export function computeNextDue(anchorDate, freqType, interval = 1, refDate = todayStr()) {
  if (!anchorDate || !freqType || freqType === 'ONE_TIME') return anchorDate || ''
  const anchor = parseISODate(anchorDate)
  const ref = parseISODate(refDate) || todayObj()
  if (!anchor) return ''
  let d = new Date(anchor.getFullYear(), anchor.getMonth(), anchor.getDate())
  let n = 0
  const guard = 2000
  if (freqType === 'MONTH') {
    while (d < ref && n++ < guard) {
      const day = Math.min(d.getDate(), lastDayOfMonth(new Date(d.getFullYear(), d.getMonth() + interval, 1)))
      d = new Date(d.getFullYear(), d.getMonth() + interval, day)
    }
  } else if (freqType === 'YEAR') {
    while (d < ref && n++ < guard) {
      d = new Date(d.getFullYear() + interval, d.getMonth(), Math.min(d.getDate(), lastDayOfMonth(new Date(d.getFullYear() + interval, d.getMonth(), 1))))
    }
  } else {
    return anchorDate || ''
  }
  return toISODate(d)
}

export function computeRenewal(dueDate, remindDays) {
  if (!dueDate || !Number(remindDays)) return ''
  const due = parseISODate(dueDate)
  if (!due) return ''
  const r = new Date(due.getFullYear(), due.getMonth(), due.getDate() - Number(remindDays))
  return toISODate(r)
}

export const REMIND_BEFORE_OPTIONS = [
  { value: 0, label: 'At due time' },
  { value: 5, label: '5 minutes before' },
  { value: 15, label: '15 minutes before' },
  { value: 30, label: '30 minutes before' },
  { value: 60, label: '1 hour before' },
  { value: 120, label: '2 hours before' },
  { value: 1440, label: '1 day before' },
  { value: 2880, label: '2 days before' },
  { value: 10080, label: '1 week before' },
  { value: -1, label: 'Custom' },
]

export function todayStr() {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

export function todayObj() {
  return new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate())
}

export function daysLeft(dateStr) {
  if (!dateStr) return null
  const today = todayObj()
  const target = new Date(`${String(dateStr).slice(0, 10)}T00:00:00`)
  return Math.round((target - today) / 86400000)
}

export function isPaidByTenant(reminder) {
  if (/paid by tenant/i.test(reminder?.due_date_display || '')) return true
  if (/paid by tenant/i.test(reminder?.renewal_date_display || '')) return true
  if (/paid by tenant/i.test(reminder?.notes || '')) return true
  return false
}

export function derivedStatus(reminder) {
  if (reminder.completed_at) return 'Completed'
  if (reminder.snooze_until && new Date(reminder.snooze_until) > new Date()) return 'Snoozed'
  if (isPaidByTenant(reminder)) return 'Paid'
  const dl = daysLeft(reminder.due_date || reminder.renewal_date)
  if (dl === null) return reminder.status || 'Upcoming'
  if (dl < 0) return 'Overdue'
  if (dl === 0) return 'Due Today'
  if (dl === 1) return 'Due Tomorrow'
  if (dl <= 7) return 'Due Soon'
  return 'Upcoming'
}

export function statusPillClass(status) {
  const map = {
    Overdue: 'pill-overdue',
    'Due Today': 'pill-due-today',
    'Due Tomorrow': 'pill-due-today',
    'Due Soon': 'pill-due-soon',
    Upcoming: 'pill-upcoming',
    Paid: 'pill-completed',
    Completed: 'pill-completed',
    Snoozed: 'pill-snoozed',
  }
  return map[status] || 'pill-neutral'
}

export function priorityPillClass(priority) {
  const map = { Low: 'pill-low', Medium: 'pill-medium', High: 'pill-high', Critical: 'pill-critical' }
  return map[priority] || 'pill-neutral'
}

export function statusDotClass(status) {
  const map = {
    Overdue: 'dot-overdue',
    'Due Today': 'dot-due-today',
    'Due Tomorrow': 'dot-due-today',
    'Due Soon': 'dot-due-soon',
    Upcoming: 'dot-upcoming',
    Paid: 'dot-completed',
    Completed: 'dot-completed',
    Snoozed: 'dot-snoozed',
  }
  return map[status] || 'dot-upcoming'
}

export function formatDate(d) {
  if (!d) return '—'
  const s = String(d).slice(0, 10)
  const [y, m, day] = s.split('-')
  if (!y || !m || !day) return d
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  return `${day} ${months[Number(m) - 1]} ${y}`
}

export function formatDateTime(d) {
  if (!d) return '—'
  try {
    const dt = new Date(d)
    const date = formatDate(dt.toISOString().slice(0, 10))
    let h = dt.getHours()
    const m = String(dt.getMinutes()).padStart(2, '0')
    const ampm = h >= 12 ? 'PM' : 'AM'
    h = h % 12 || 12
    return `${date}, ${h}:${m} ${ampm}`
  } catch { return d }
}

export function categoryLabel(key) {
  const found = CATEGORIES.find(c => c.key === key)
  return found ? found.label : key || '—'
}

export function normalizeCategory(val) {
  if (!val) return 'Other'
  const lower = val.toLowerCase()
  const byKey = CATEGORIES.find(c => c.key === val)
  if (byKey) return byKey.label
  const byLabel = CATEGORIES.find(c => c.label.toLowerCase() === lower)
  if (byLabel) return byLabel.label
  return val
}

export function categoryIcon(key) {
  const found = CATEGORIES.find(c => c.key === key)
  return found ? found.icon : 'bell'
}

function downloadBlob(content, filename, mime) {
  const blob = new Blob([content], { type: mime })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  setTimeout(() => URL.revokeObjectURL(url), 500)
}

export const EXPORT_COLUMNS = [
  'Category', 'Section', 'Reminder / Property / Item', 'Owner', 'Due Date', 'Renewal Date',
  'Last Paid Date', 'Paid Amount', 'Status', 'Billing Cycle', 'Transaction ID', 'Notes',
]

function billingCycleLabel(r) {
  if (r.display_frequency) return r.display_frequency
  return parseFrequencyLabel(r.frequency_type, r.frequency_interval, r.day_of_month, r.month_of_year) || '—'
}

export function toExportRow(r) {
  return [
    normalizeCategory(r.category) || '—',
    r.source_section || '—',
    r.title || '—',
    r.owner || '—',
    r.due_date ? formatDate(r.due_date) : '—',
    r.renewal_date ? formatDate(r.renewal_date) : '—',
    r.paid_at ? formatDate(r.paid_at) : '—',
    r.amount ? `₹${r.amount}` : '—',
    derivedStatus(r),
    billingCycleLabel(r),
    r.transaction_id || '—',
    r.notes || '—',
  ]
}

export function exportToCSV(reminders) {
  const header = EXPORT_COLUMNS
  const rows = [header, ...reminders.map(r => toExportRow(r))]
  const csv = rows.map(r => r.map(v => {
    const s = String(v ?? '')
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
  }).join(',')).join('\n')
  downloadBlob('\ufeff' + csv, `reminders-${todayStr()}.csv`, 'text/csv;charset=utf-8;')
}

function xmlEscape(s) { return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') }

export function exportToExcel(reminders) {
  const header = EXPORT_COLUMNS
  const rows = reminders.map(r => toExportRow(r))
  const all = [header, ...rows]
  const body = all.map(r => {
    const cells = r.map(v => `<Cell><Data ss:Type="String">${xmlEscape(v)}</Data></Cell>`).join('')
    return `<Row>${cells}</Row>`
  }).join('')
  const xml = `<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet ss:Name="Reminders"><Table>${body}</Table></Worksheet></Workbook>`
  downloadBlob(xml, `reminders-${todayStr()}.xls`, 'application/vnd.ms-excel')
}

export function parseFrequencyLabel(freqType, interval, day, month) {
  if (!freqType || freqType === 'ONE_TIME') return 'One Time'
  const suffix = (n) => { if (n === 1) return ''; return ` ${n}` }
  const ord = (n) => {
    if (n === 1) return '1st'
    if (n === 2) return '2nd'
    if (n === 3) return '3rd'
    return `${n}th`
  }
  switch (freqType) {
    case 'DAY': return interval > 1 ? `Every ${interval} days` : 'Every Day'
    case 'WEEK': return interval > 1 ? `Every ${interval} weeks` : 'Every Week'
    case 'MONTH': {
      if (day) {
        return interval > 1 ? `${ord(day)} of Every ${interval} Months` : `${ord(day)} of Every Month`
      }
      return interval > 1 ? `Every ${interval} Months` : 'Every Month'
    }
    case 'YEAR': {
      if (day && month) {
        const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        return interval > 1 ? `${ord(day)} ${m[month - 1]} Every ${interval} Years` : `${ord(day)} ${m[month - 1]} Every Year`
      }
      return interval > 1 ? `Every ${interval} Years` : 'Every Year'
    }
    default: return freqType
  }
}
